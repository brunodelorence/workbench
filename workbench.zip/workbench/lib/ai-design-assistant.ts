"use client"

// AI Design Assistant - Command Parser
// Based on the system prompt specification

export interface AIResponse {
  type: "action" | "clarification" | "suggestion"
  elementId: string | null
  changes: Record<string, string>
  action: "style" | "content" | "layout" | "select" | "unknown"
  description: string
  message: string
}

// Element mapping based on user keywords
const ELEMENT_KEYWORDS: Record<string, string[]> = {
  "hero-title": ["título", "title", "heading", "cabeçalho", "hero title", "main title"],
  "hero-subtitle": ["subtítulo", "subtitle", "sub-título", "tagline"],
  "hero-description": ["descrição", "description", "texto principal", "hero description"],
  "hero-cta-primary": ["botão principal", "primary button", "cta principal", "botão de ação", "main button", "primary cta", "get started", "começar"],
  "hero-cta-secondary": ["botão secundário", "secondary button", "cta secundário", "second button", "learn more", "saiba mais"],
  "nav": ["navegação", "nav", "menu", "header", "navbar"],
  "footer": ["rodapé", "footer"],
  "features-title": ["título de features", "features title", "título da seção"],
  "features-subtitle": ["subtítulo de features", "features subtitle"],
  "feature-card-0": ["primeiro card", "first card", "card 1", "feature 1"],
  "feature-card-1": ["segundo card", "second card", "card 2", "feature 2"],
  "feature-card-2": ["terceiro card", "third card", "card 3", "feature 3"],
  "feature-card-3": ["quarto card", "fourth card", "card 4", "feature 4"],
  "cta-section": ["seção cta", "cta section", "call to action"],
  "logo-section": ["logos", "logo section", "parceiros", "partners"],
}

// Color mapping
const COLOR_KEYWORDS: Record<string, { bg: string; text: string }> = {
  "azul": { bg: "bg-blue-600", text: "text-blue-600" },
  "blue": { bg: "bg-blue-600", text: "text-blue-600" },
  "verde": { bg: "bg-green-600", text: "text-green-600" },
  "green": { bg: "bg-green-600", text: "text-green-600" },
  "vermelho": { bg: "bg-red-600", text: "text-red-600" },
  "red": { bg: "bg-red-600", text: "text-red-600" },
  "roxo": { bg: "bg-purple-600", text: "text-purple-600" },
  "purple": { bg: "bg-purple-600", text: "text-purple-600" },
  "violeta": { bg: "bg-violet-600", text: "text-violet-600" },
  "violet": { bg: "bg-violet-600", text: "text-violet-600" },
  "laranja": { bg: "bg-orange-500", text: "text-orange-500" },
  "orange": { bg: "bg-orange-500", text: "text-orange-500" },
  "rosa": { bg: "bg-pink-600", text: "text-pink-600" },
  "pink": { bg: "bg-pink-600", text: "text-pink-600" },
  "amarelo": { bg: "bg-yellow-500", text: "text-yellow-500" },
  "yellow": { bg: "bg-yellow-500", text: "text-yellow-500" },
  "preto": { bg: "bg-gray-900", text: "text-gray-900" },
  "black": { bg: "bg-gray-900", text: "text-gray-900" },
  "branco": { bg: "bg-white", text: "text-white" },
  "white": { bg: "bg-white", text: "text-white" },
  "cinza": { bg: "bg-gray-500", text: "text-gray-500" },
  "gray": { bg: "bg-gray-500", text: "text-gray-500" },
  "grey": { bg: "bg-gray-500", text: "text-gray-500" },
  "escuro": { bg: "bg-gray-800", text: "text-gray-800" },
  "dark": { bg: "bg-gray-800", text: "text-gray-800" },
  "claro": { bg: "bg-gray-100", text: "text-gray-100" },
  "light": { bg: "bg-gray-100", text: "text-gray-100" },
}

// Size mapping
const SIZE_KEYWORDS: Record<string, string> = {
  "muito grande": "5xl",
  "extra large": "5xl",
  "huge": "5xl",
  "grande": "3xl",
  "large": "3xl",
  "médio": "xl",
  "medium": "xl",
  "pequeno": "base",
  "small": "base",
  "muito pequeno": "sm",
  "extra small": "sm",
  "tiny": "sm",
}

// Font weight mapping
const WEIGHT_KEYWORDS: Record<string, string> = {
  "negrito": "Bold",
  "bold": "Bold",
  "forte": "Bold",
  "médio": "Medium",
  "medium": "Medium",
  "regular": "Regular",
  "normal": "Regular",
  "leve": "Regular",
  "light": "Regular",
}

// Layout type mapping
const LAYOUT_KEYWORDS: Record<string, string> = {
  "cards": "cards",
  "cartões": "cards",
  "lista": "list",
  "list": "list",
  "grade": "grid",
  "grid": "grid",
  "padrão": "default",
  "default": "default",
}

// Alignment mapping
const ALIGNMENT_KEYWORDS: Record<string, string> = {
  "esquerda": "left",
  "left": "left",
  "centro": "center",
  "center": "center",
  "centralizado": "center",
  "direita": "right",
  "right": "right",
}

export function parseDesignCommand(
  command: string, 
  selectedElementId: string | null,
  conversationContext: string[] = []
): AIResponse {
  const lowerCommand = command.toLowerCase().trim()
  
  // Try to identify the target element
  let targetElement = selectedElementId
  for (const [elementId, keywords] of Object.entries(ELEMENT_KEYWORDS)) {
    for (const keyword of keywords) {
      if (lowerCommand.includes(keyword.toLowerCase())) {
        targetElement = elementId
        break
      }
    }
    if (targetElement !== selectedElementId) break
  }

  // Check for content change (text modification)
  const contentMatch = lowerCommand.match(/(?:escreva|write|mude o texto para|altere o texto para|change text to|set text to|título para|title to)[:\s]+["']?([^"']+)["']?/i)
  || lowerCommand.match(/["']([^"']+)["']/i)
  
  if (contentMatch && (lowerCommand.includes("escreva") || lowerCommand.includes("write") || lowerCommand.includes("texto") || lowerCommand.includes("text") || lowerCommand.includes("título") || lowerCommand.includes("title"))) {
    const newContent = contentMatch[1].trim()
    if (!targetElement) {
      return {
        type: "clarification",
        elementId: null,
        changes: {},
        action: "unknown",
        description: "Clarification needed: which element to modify.",
        message: "Em qual elemento você gostaria de alterar o texto? Por exemplo: 'no título', 'no subtítulo', 'no botão principal'."
      }
    }
    return {
      type: "action",
      elementId: targetElement,
      changes: { content: newContent },
      action: "content",
      description: `Content of ${targetElement} changed to "${newContent}".`,
      message: `Pronto! O texto foi alterado para "${newContent}".`
    }
  }

  // Check for color change
  let detectedColor: { bg: string; text: string } | null = null
  for (const [colorName, colorValues] of Object.entries(COLOR_KEYWORDS)) {
    if (lowerCommand.includes(colorName)) {
      detectedColor = colorValues
      break
    }
  }

  if (detectedColor) {
    const isBackground = lowerCommand.includes("fundo") || lowerCommand.includes("background") || lowerCommand.includes("bg")
    const isText = lowerCommand.includes("texto") || lowerCommand.includes("text") || lowerCommand.includes("cor do texto") || lowerCommand.includes("text color")
    
    if (!targetElement) {
      // Try to infer from context or ask
      if (selectedElementId) {
        targetElement = selectedElementId
      } else {
        return {
          type: "clarification",
          elementId: null,
          changes: {},
          action: "unknown",
          description: "Clarification needed: which element to modify.",
          message: "Qual elemento você gostaria de alterar? Por exemplo: 'o título', 'o botão principal', 'o subtítulo'."
        }
      }
    }

    const changes: Record<string, string> = {}
    if (isText && !isBackground) {
      changes.color = detectedColor.text
    } else if (isBackground && !isText) {
      changes.background = detectedColor.bg
    } else {
      // Default: if it's a button, change background; otherwise change text
      if (targetElement?.includes("cta") || targetElement?.includes("button")) {
        changes.background = detectedColor.bg
      } else {
        changes.color = detectedColor.text
      }
    }

    const colorName = Object.entries(COLOR_KEYWORDS).find(([_, v]) => v === detectedColor)?.[0] || "nova cor"
    return {
      type: "action",
      elementId: targetElement,
      changes,
      action: "style",
      description: `Color changed for ${targetElement}.`,
      message: `Pronto! A cor foi alterada para ${colorName}.`
    }
  }

  // Check for size change
  const increaseSizeKeywords = ["maior", "bigger", "larger", "increase", "aumentar", "aumenta", "aumente"]
  const decreaseSizeKeywords = ["menor", "smaller", "decrease", "diminuir", "diminua", "reduzir", "reduza"]
  
  const wantsIncrease = increaseSizeKeywords.some(k => lowerCommand.includes(k))
  const wantsDecrease = decreaseSizeKeywords.some(k => lowerCommand.includes(k))
  
  if (wantsIncrease || wantsDecrease) {
    if (!targetElement && selectedElementId) {
      targetElement = selectedElementId
    }
    
    if (!targetElement) {
      return {
        type: "clarification",
        elementId: null,
        changes: {},
        action: "unknown",
        description: "Clarification needed: which element to resize.",
        message: "Qual elemento você gostaria de redimensionar? Por exemplo: 'o título', 'a fonte do subtítulo'."
      }
    }

    // Determine new size based on increase/decrease
    const newSize = wantsIncrease ? "4xl" : "lg"
    return {
      type: "action",
      elementId: targetElement,
      changes: { fontSize: newSize },
      action: "style",
      description: `Font size of ${targetElement} ${wantsIncrease ? 'increased' : 'decreased'}.`,
      message: `Feito! O tamanho foi ${wantsIncrease ? 'aumentado' : 'diminuído'}.`
    }
  }

  // Check for specific size
  for (const [sizeKeyword, sizeValue] of Object.entries(SIZE_KEYWORDS)) {
    if (lowerCommand.includes(sizeKeyword)) {
      if (!targetElement && selectedElementId) {
        targetElement = selectedElementId
      }
      if (!targetElement) {
        return {
          type: "clarification",
          elementId: null,
          changes: {},
          action: "unknown",
          description: "Clarification needed: which element to resize.",
          message: "Qual elemento você gostaria de redimensionar?"
        }
      }
      return {
        type: "action",
        elementId: targetElement,
        changes: { fontSize: sizeValue },
        action: "style",
        description: `Font size of ${targetElement} changed to ${sizeValue}.`,
        message: `Pronto! O tamanho foi ajustado para ${sizeKeyword}.`
      }
    }
  }

  // Check for font weight change
  for (const [weightKeyword, weightValue] of Object.entries(WEIGHT_KEYWORDS)) {
    if (lowerCommand.includes(weightKeyword)) {
      if (!targetElement && selectedElementId) {
        targetElement = selectedElementId
      }
      if (!targetElement) {
        return {
          type: "clarification",
          elementId: null,
          changes: {},
          action: "unknown",
          description: "Clarification needed: which element to modify.",
          message: "Qual elemento você gostaria de deixar em negrito/regular?"
        }
      }
      return {
        type: "action",
        elementId: targetElement,
        changes: { fontWeight: weightValue },
        action: "style",
        description: `Font weight of ${targetElement} changed to ${weightValue}.`,
        message: `Feito! O peso da fonte foi alterado para ${weightKeyword}.`
      }
    }
  }

  // Check for alignment change
  for (const [alignKeyword, alignValue] of Object.entries(ALIGNMENT_KEYWORDS)) {
    if (lowerCommand.includes(alignKeyword) || lowerCommand.includes("centralize") || lowerCommand.includes("alinhe") || lowerCommand.includes("align")) {
      if (!targetElement && selectedElementId) {
        targetElement = selectedElementId
      }
      if (!targetElement) {
        return {
          type: "clarification",
          elementId: null,
          changes: {},
          action: "unknown",
          description: "Clarification needed: which element to align.",
          message: "Qual elemento você gostaria de alinhar?"
        }
      }
      return {
        type: "action",
        elementId: targetElement,
        changes: { textAlign: alignValue },
        action: "style",
        description: `Text alignment of ${targetElement} changed to ${alignValue}.`,
        message: `Pronto! O alinhamento foi alterado para ${alignKeyword}.`
      }
    }
  }

  // Check for layout change
  for (const [layoutKeyword, layoutValue] of Object.entries(LAYOUT_KEYWORDS)) {
    if (lowerCommand.includes(layoutKeyword) || lowerCommand.includes("layout") || lowerCommand.includes("exiba") || lowerCommand.includes("mostre")) {
      return {
        type: "action",
        elementId: targetElement,
        changes: { layoutType: layoutValue },
        action: "layout",
        description: `Layout changed to ${layoutValue}.`,
        message: `Layout alterado para ${layoutKeyword}! As mudanças foram aplicadas.`
      }
    }
  }

  // Check for element selection
  if (lowerCommand.includes("selecione") || lowerCommand.includes("select") || lowerCommand.includes("escolha")) {
    if (targetElement) {
      return {
        type: "action",
        elementId: targetElement,
        changes: {},
        action: "select",
        description: `Element ${targetElement} selected.`,
        message: `Ok, o elemento foi selecionado. O que você gostaria de fazer com ele?`
      }
    }
  }

  // Check for vague commands that need suggestions
  const vagueKeywords = ["melhore", "improve", "bonito", "beautiful", "melhor", "better", "legal", "nice", "moderno", "modern"]
  if (vagueKeywords.some(k => lowerCommand.includes(k))) {
    return {
      type: "suggestion",
      elementId: targetElement,
      changes: {},
      action: "unknown",
      description: "Proactive suggestion offered.",
      message: "Ótima ideia! Aqui estão algumas sugestões para melhorar o visual:\n\n1. **Aumentar o contraste:** Deixar o título mais escuro ou o fundo mais claro.\n2. **Adicionar espaçamento:** Aumentar o padding entre as seções.\n3. **Modernizar a fonte:** Usar um peso de fonte mais forte para títulos.\n4. **Cores vibrantes:** Usar cores mais chamativas nos botões.\n\nQual dessas opções você gostaria de experimentar?"
    }
  }

  // Check for padding/margin changes
  if (lowerCommand.includes("padding") || lowerCommand.includes("preenchimento") || lowerCommand.includes("espaçamento interno")) {
    if (!targetElement && selectedElementId) {
      targetElement = selectedElementId
    }
    const increase = wantsIncrease || lowerCommand.includes("mais")
    const newPadding = increase ? "24px" : "8px"
    return {
      type: "action",
      elementId: targetElement,
      changes: { paddingX: newPadding, paddingY: newPadding },
      action: "style",
      description: `Padding of ${targetElement} changed.`,
      message: `Pronto! O espaçamento interno foi ${increase ? 'aumentado' : 'diminuído'}.`
    }
  }

  // Default: didn't understand
  return {
    type: "clarification",
    elementId: null,
    changes: {},
    action: "unknown",
    description: "Command not understood.",
    message: "Desculpe, não consegui entender o que você gostaria de fazer. Você poderia ser mais específico? Por exemplo:\n\n- 'Mude a cor do botão para azul'\n- 'Aumente o tamanho do título'\n- 'Escreva \"Novo Texto\" no subtítulo'\n- 'Centralize o título'\n- 'Deixe o botão em negrito'"
  }
}

// Helper to apply AI response changes to element styles
export function applyAIChanges(
  response: AIResponse,
  currentStyles: Record<string, any>,
  currentContent: Record<string, string>
): {
  newStyles: Record<string, any>
  newContent: Record<string, string>
  selectedElement: string | null
} {
  const newStyles = { ...currentStyles }
  const newContent = { ...currentContent }
  let selectedElement: string | null = null

  if (response.type === "action" && response.elementId) {
    if (response.action === "select") {
      selectedElement = response.elementId
    } else if (response.action === "content" && response.changes.content) {
      newContent[response.elementId] = response.changes.content
    } else if (response.action === "style" || response.action === "layout") {
      const elementStyles = newStyles[response.elementId] || {}
      
      for (const [key, value] of Object.entries(response.changes)) {
        if (key === "color") {
          elementStyles.color = value
        } else if (key === "background") {
          elementStyles.background = value
        } else if (key === "fontSize") {
          elementStyles.fontSize = value
        } else if (key === "fontWeight") {
          elementStyles.fontWeight = value
        } else if (key === "textAlign") {
          elementStyles.textAlign = value
        } else if (key === "paddingX") {
          elementStyles.paddingX = value
        } else if (key === "paddingY") {
          elementStyles.paddingY = value
        }
      }
      
      newStyles[response.elementId] = elementStyles
    }
  }

  return { newStyles, newContent, selectedElement }
}

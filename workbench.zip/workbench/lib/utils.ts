import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function classNames(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Alias for backward compatibility
export const cn = classNames

"use client"

import { useState, useCallback } from "react"
import { RedesignPage } from "@/components/onboarding/redesign-page"
import { AppLoading } from "@/components/onboarding/app-loading"
import { EditorSidebar, ChatMessage, TemplateType, BrandStyles } from "@/components/editor/editor-sidebar"
import { PreviewCanvas } from "@/components/editor/preview-canvas"
import { EditorHeader } from "@/components/editor/editor-header"
import { CodeView } from "@/components/editor/code-view"
import { CompareView } from "@/components/editor/compare-view"
import { RecommendationsPanel } from "@/components/editor/recommendations-panel"
import { BrandPanel } from "@/components/editor/brand-panel"
import { parseDesignCommand, applyAIChanges, type AIResponse } from "@/lib/ai-design-assistant"

type AppState = "onboarding" | "loading" | "editor"

interface ElementStyles {
  fontFamily: string
  fontWeight: string
  fontSize: string
  lineHeight: string
  letterSpacing: string
  textAlign: string
  textDecoration: string
  color: string
  background: string
  marginX: string
  marginY: string
  paddingX: string
  paddingY: string
  gapX: string
  gapY: string
  borderStyle: string
  borderColor: string
  content?: string
  layoutType?: "default" | "cards" | "list" | "grid"
}

const defaultStyles: ElementStyles = {
  fontFamily: "default",
  fontWeight: "Medium",
  fontSize: "sm",
  lineHeight: "1.75rem",
  letterSpacing: "0em",
  textAlign: "center",
  textDecoration: "none",
  color: "text-gray-700",
  background: "Default",
  marginX: "0px",
  marginY: "0px",
  paddingX: "0px",
  paddingY: "0px",
  gapX: "0px",
  gapY: "0px",
  borderStyle: "Default",
  borderColor: "Default",
}

const elementDefaultStyles: Record<string, Partial<ElementStyles>> = {
  "hero-heading": {
    fontWeight: "Bold",
    fontSize: "5xl",
    color: "text-gray-900",
    textAlign: "center",
    lineHeight: "1.1",
  },
  "hero-subtitle": {
    fontWeight: "Regular",
    fontSize: "xl",
    color: "text-gray-600",
    textAlign: "center",
    lineHeight: "1.6",
  },
  "hero-cta-primary": {
    fontWeight: "Medium",
    fontSize: "base",
    color: "text-white",
    background: "bg-gray-900",
  },
  "hero-cta-secondary": {
    fontWeight: "Medium",
    fontSize: "base",
    color: "text-gray-700",
    background: "bg-white",
  },
  "features-title": {
    fontWeight: "Bold",
    fontSize: "3xl",
    color: "text-gray-900",
  },
  "features-subtitle": {
    fontWeight: "Regular",
    fontSize: "lg",
    color: "text-gray-600",
  },
}



export default function LayoutEditor() {
  // App state flow: onboarding -> loading -> editor
  const [appState, setAppState] = useState<AppState>("onboarding")
  const [redesignUrl, setRedesignUrl] = useState("")
  const [redesignPrompt, setRedesignPrompt] = useState("")
  const [currentTemplate, setCurrentTemplate] = useState<TemplateType>("marketing")

  // Editor state
  const [selectedElementId, setSelectedElementId] = useState<string | null>("hero-heading")
  const [currentVersion, setCurrentVersion] = useState(1)
  const [activeTab, setActiveTab] = useState("preview")
  const [isRecommendationsOpen, setIsRecommendationsOpen] = useState(false)
  const [isBrandPanelOpen, setIsBrandPanelOpen] = useState(false)
  const [hasBrandStyle, setHasBrandStyle] = useState(false)
  const [brandStyles, setBrandStyles] = useState<BrandStyles | null>(null)
  const [sidebarTab, setSidebarTab] = useState<"properties" | "chat">("chat")
  const [styles, setStyles] = useState<ElementStyles>({
    ...defaultStyles,
    ...elementDefaultStyles["hero-heading"]
  })

  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [isChatProcessing, setIsChatProcessing] = useState(false)

  // Store styles for each element
  const [elementStyles, setElementStyles] = useState<Record<string, ElementStyles>>({
    "hero-heading": { ...defaultStyles, ...elementDefaultStyles["hero-heading"] },
    "hero-subtitle": { ...defaultStyles, ...elementDefaultStyles["hero-subtitle"] },
    "hero-cta-primary": { ...defaultStyles, ...elementDefaultStyles["hero-cta-primary"] },
    "hero-cta-secondary": { ...defaultStyles, ...elementDefaultStyles["hero-cta-secondary"] },
    "features-title": { ...defaultStyles, ...elementDefaultStyles["features-title"] },
    "features-subtitle": { ...defaultStyles, ...elementDefaultStyles["features-subtitle"] },
  })

  // Element content state
  const [elementContent, setElementContent] = useState<Record<string, string>>({
    "hero-heading": "Build AI-Powered Apps 10x Faster",
    "hero-subtitle": "The complete platform for building, deploying, and scaling intelligent applications. From prototype to production in minutes, not months.",
    "hero-cta-primary": "Start Building Free",
    "hero-cta-secondary": "Watch Demo",
    "features-title": "Everything you need to build with AI",
    "features-subtitle": "Powerful features that help you ship faster and scale effortlessly",
  })

  const handleStartRedesign = (url: string, prompt: string) => {
    setRedesignUrl(url)
    setRedesignPrompt(prompt)
    setAppState("loading")
    
    // Initialize chat with user's prompt
    setChatMessages([
      {
        id: "initial",
        role: "user",
        content: `Redesign ${url}\n\n${prompt}`,
        timestamp: new Date()
      }
    ])
  }

  const handleLoadingComplete = () => {
    setAppState("editor")
    setSidebarTab("chat")
    
    // Add AI response to chat
    setChatMessages(prev => [
      ...prev,
      {
        id: "response-1",
        role: "assistant",
        content: `I've analyzed the website and created a modern redesign based on your requirements. Here's what I've done:\n\n1. **Clean Hero Section**: Simplified the hero with clear messaging and strong CTA\n2. **Modern Typography**: Using clean, readable fonts with proper hierarchy\n3. **Feature Cards**: Added professional feature showcase\n4. **Improved Visual Flow**: Better spacing and visual balance\n\nYou can now ask me to make any changes! Try commands like:\n• "Make the button blue"\n• "Make the heading bigger"\n• "Change the subtitle text to 'Your new description'"\n• "Change to card layout"`,
        timestamp: new Date(),
        colors: ["#2970ff", "#e9eaeb", "#18181b", "#71717a", "#155eef"],
        createdUI: "Created UI v1",
        issues: "No issues found"
      }
    ])
  }

  const handleApplyBrandStyles = useCallback((styles: BrandStyles) => {
    setBrandStyles(styles)
    setHasBrandStyle(true)
    
    // Apply brand colors to elements
    setElementStyles(prev => ({
      ...prev,
      "hero-cta-primary": {
        ...prev["hero-cta-primary"],
        background: `bg-[${styles.primary}]`,
        color: styles.primaryForeground === "#000000" ? "text-black" : "text-white"
      },
      "hero-heading": {
        ...prev["hero-heading"],
        color: `text-[${styles.foreground}]`
      },
      "hero-subtitle": {
        ...prev["hero-subtitle"],
        color: `text-[${styles.mutedForeground}]`
      }
    }))
    
    // Add message about brand style
    setChatMessages(prev => [
      ...prev,
      {
        id: `brand-${Date.now()}`,
        role: "assistant",
        content: `Brand style has been applied! I've updated the primary colors to match your brand.\n\n**Primary**: ${styles.primary}\n**Background**: ${styles.background}\n**Text**: ${styles.foreground}`,
        timestamp: new Date(),
        colors: [styles.primary, styles.secondary, styles.foreground, styles.mutedForeground, styles.accent],
        createdUI: `Applied brand style v${currentVersion + 1}`,
        issues: "No issues found"
      }
    ])
    
    setCurrentVersion(prev => prev + 1)
  }, [currentVersion])

  const handleTemplateChange = useCallback((template: TemplateType) => {
    setCurrentTemplate(template)
    setCurrentVersion(prev => prev + 1)
    
    // Add message about template change
    setChatMessages(prev => [
      ...prev,
      {
        id: `template-${Date.now()}`,
        role: "assistant",
        content: `Template changed to **${template.charAt(0).toUpperCase() + template.slice(1)}**. The entire layout has been updated. You can continue customizing the new template.`,
        timestamp: new Date(),
        createdUI: `Switched to ${template} template v${currentVersion + 1}`,
        issues: "No issues found"
      }
    ])
  }, [currentVersion])

  const handleSendChatMessage = useCallback((message: string) => {
    // Add user message
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: message,
      timestamp: new Date()
    }
    setChatMessages(prev => [...prev, userMessage])
    setIsChatProcessing(true)

    // Use AI Design Assistant to parse command
    const aiResponse = parseDesignCommand(message, selectedElementId, [])
    
    // Simulate AI processing with typing effect
    setTimeout(() => {
      let appliedChanges = false
      let targetElement = aiResponse.elementId
      
      if (aiResponse.type === "action" && aiResponse.elementId) {
        // Apply the AI changes
        const { newStyles, newContent, selectedElement } = applyAIChanges(
          aiResponse,
          elementStyles,
          elementContent
        )
        
        // Handle element selection
        if (selectedElement) {
          setSelectedElementId(selectedElement)
          targetElement = selectedElement
        }
        
        // Apply content changes
        if (aiResponse.action === "content" && aiResponse.changes.content) {
          setElementContent(prev => ({
            ...prev,
            [aiResponse.elementId!]: aiResponse.changes.content!
          }))
          appliedChanges = true
        }
        
        // Apply style changes
        if (aiResponse.action === "style" || aiResponse.action === "layout") {
          const styleChanges = { ...aiResponse.changes }
          delete styleChanges.content
          
          if (Object.keys(styleChanges).length > 0) {
            setElementStyles(prev => ({
              ...prev,
              [aiResponse.elementId!]: {
                ...prev[aiResponse.elementId!],
                ...styleChanges
              }
            }))
            
            if (selectedElementId === aiResponse.elementId) {
              setStyles(prev => ({
                ...prev,
                ...styleChanges
              }))
            }
            appliedChanges = true
          }
        }
        
        // Select the element to show changes
        if (aiResponse.action !== "select") {
          setSelectedElementId(aiResponse.elementId)
        }
      }

      const chatResponse: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: "assistant",
        content: aiResponse.message,
        timestamp: new Date(),
        createdUI: appliedChanges ? `Updated ${targetElement?.replace(/-/g, " ")} v${currentVersion + 1}` : undefined,
        issues: appliedChanges ? "No issues found" : undefined,
        colors: appliedChanges ? ["#2970ff", "#e9eaeb", "#18181b", "#71717a", "#155eef"] : undefined
      }
      
      setChatMessages(prev => [...prev, chatResponse])
      setIsChatProcessing(false)
      
      if (appliedChanges) {
        setCurrentVersion(prev => prev + 1)
      }
    }, 1200)
  }, [selectedElementId, currentVersion, elementStyles, elementContent])

  const handleStyleChange = (newStyles: Partial<ElementStyles>) => {
    setStyles(prev => ({ ...prev, ...newStyles }))
    
    // Also update elementStyles for the selected element
    if (selectedElementId) {
      setElementStyles(prev => ({
        ...prev,
        [selectedElementId]: {
          ...prev[selectedElementId],
          ...newStyles
        }
      }))
    }
  }

  const handleSelectElement = (id: string | null) => {
    setSelectedElementId(id)
    // Load element's actual styles when selecting
    if (id && elementStyles[id]) {
      setStyles(elementStyles[id])
    } else if (id && elementDefaultStyles[id]) {
      setStyles({
        ...defaultStyles,
        ...elementDefaultStyles[id]
      })
    } else {
      setStyles(defaultStyles)
    }
  }

  const handleApplySuggestion = (elementId: string, changes: { property: string; value: string }[]) => {
    // Update the element styles
    setElementStyles(prev => {
      const currentStyles = prev[elementId] || { ...defaultStyles, ...elementDefaultStyles[elementId] }
      const newStyles = { ...currentStyles }
      
      for (const change of changes) {
        (newStyles as Record<string, string>)[change.property] = change.value
      }
      
      return {
        ...prev,
        [elementId]: newStyles
      }
    })

    // If this is the currently selected element, also update the sidebar
    if (selectedElementId === elementId) {
      setStyles(prev => {
        const newStyles = { ...prev }
        for (const change of changes) {
          (newStyles as Record<string, string>)[change.property] = change.value
        }
        return newStyles
      })
    }

    // Select the element to show the changes
    setSelectedElementId(elementId)
  }

  const getElementType = () => {
    switch (selectedElementId) {
      case "hero-heading":
      case "features-title":
        return "h1"
      case "hero-subtitle":
      case "features-subtitle":
        return "p"
      case "hero-cta-primary":
      case "hero-cta-secondary":
        return "button"
      case "nav":
        return "nav"
      default:
        return "div"
    }
  }

  // Render based on app state
  if (appState === "onboarding") {
    return <RedesignPage onStartRedesign={handleStartRedesign} />
  }

  if (appState === "loading") {
    return (
      <AppLoading 
        url={redesignUrl} 
        prompt={redesignPrompt} 
        onComplete={handleLoadingComplete} 
      />
    )
  }

  // Editor view
  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <EditorHeader
        currentVersion={currentVersion}
        totalVersions={8}
        onVersionChange={setCurrentVersion}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenRecommendations={() => setIsRecommendationsOpen(true)}
        onOpenBrand={() => setIsBrandPanelOpen(true)}
        onGoHome={() => setAppState("onboarding")}
        redesignUrl={redesignUrl}
      />
      
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar with Properties/Chat tabs - only show on preview and code tabs */}
        {(activeTab === "preview" || activeTab === "code") && (
          <EditorSidebar 
            selectedElementId={selectedElementId}
            selectedElementType={getElementType()}
            styles={styles}
            onStyleChange={handleStyleChange}
            chatMessages={chatMessages}
            onSendChatMessage={handleSendChatMessage}
            isChatProcessing={isChatProcessing}
            redesignUrl={redesignUrl}
            initialTab={sidebarTab}
            onOpenBrand={() => setIsBrandPanelOpen(true)}
            onTemplateChange={handleTemplateChange}
            currentTemplate={currentTemplate}
            onApplyBrandStyles={handleApplyBrandStyles}
            hasBrandStyle={hasBrandStyle}
          />
        )}
        
        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden">
          {activeTab === "preview" && (
            <div className="h-full overflow-auto" onClick={() => setSelectedElementId(null)}>
              <PreviewCanvas 
                selectedElementId={selectedElementId}
                onSelectElement={handleSelectElement}
                elementStyles={elementStyles}
                elementContent={elementContent}
                currentTemplate={currentTemplate}
                onApplyStyles={(elementId, newStyles) => {
                  setElementStyles(prev => ({
                    ...prev,
                    [elementId]: {
                      ...prev[elementId],
                      ...newStyles
                    }
                  }))
                  if (selectedElementId === elementId) {
                    setStyles(prev => ({
                      ...prev,
                      ...newStyles
                    }))
                  }
                }}
              />
            </div>
          )}
          
          {activeTab === "code" && (
            <CodeView selectedElementId={selectedElementId} />
          )}
          
          {activeTab === "compare" && (
            <CompareView originalUrl={redesignUrl} />
          )}
        </div>

        {/* Recommendations Panel */}
        <RecommendationsPanel
          isOpen={isRecommendationsOpen}
          onClose={() => setIsRecommendationsOpen(false)}
          onApplySuggestion={handleApplySuggestion}
          selectedElementId={selectedElementId}
        />

        {/* Brand Panel */}
        <BrandPanel
          isOpen={isBrandPanelOpen}
          onClose={() => setIsBrandPanelOpen(false)}
          onApplyBrand={(brand) => {
            // Apply brand colors to elements
            setElementStyles(prev => ({
              ...prev,
              "hero-cta-primary": {
                ...prev["hero-cta-primary"],
                background: `bg-[${brand.colors.primary}]`,
                color: "text-white"
              },
              "hero-heading": {
                ...prev["hero-heading"],
                color: `text-[${brand.colors.text}]`
              },
              "hero-subtitle": {
                ...prev["hero-subtitle"],
                color: `text-[${brand.colors.muted}]`
              }
            }))
          }}
        />
      </div>
    </div>
  )
}

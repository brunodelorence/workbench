"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  X, 
  Upload, 
  Link2, 
  Check, 
  Palette, 
  Type, 
  ImageIcon,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Plus,
  Loader2
} from "lucide-react"
import { cn } from "@/lib/utils"

// Preset brand configurations
const PRESET_BRANDS = {
  nubank: {
    name: "Nubank",
    logo: "https://upload.wikimedia.org/wikipedia/commons/f/f7/Nubank_logo_2021.svg",
    colors: {
      primary: "#820AD1",
      secondary: "#00A88E", 
      accent: "#E7E2F3",
      background: "#FFFFFF",
      text: "#111111",
      muted: "#6B7280"
    },
    typography: {
      headingFont: "Graphik",
      bodyFont: "Graphik",
      headingWeight: "Bold",
      bodyWeight: "Regular"
    },
    description: "Brazilian fintech company, known for its digital banking services"
  },
  spotify: {
    name: "Spotify",
    logo: "https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_Green.png",
    colors: {
      primary: "#1DB954",
      secondary: "#191414",
      accent: "#1ED760",
      background: "#000000",
      text: "#FFFFFF",
      muted: "#B3B3B3"
    },
    typography: {
      headingFont: "Circular",
      bodyFont: "Circular",
      headingWeight: "Bold",
      bodyWeight: "Regular"
    },
    description: "Digital music streaming service"
  },
  airbnb: {
    name: "Airbnb",
    logo: "https://upload.wikimedia.org/wikipedia/commons/6/69/Airbnb_Logo_B%C3%A9lo.svg",
    colors: {
      primary: "#FF5A5F",
      secondary: "#00A699",
      accent: "#FC642D",
      background: "#FFFFFF",
      text: "#484848",
      muted: "#767676"
    },
    typography: {
      headingFont: "Cereal",
      bodyFont: "Cereal",
      headingWeight: "Bold",
      bodyWeight: "Book"
    },
    description: "Online marketplace for lodging and tourism"
  },
  stripe: {
    name: "Stripe",
    logo: "https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg",
    colors: {
      primary: "#635BFF",
      secondary: "#0A2540",
      accent: "#00D4FF",
      background: "#FFFFFF",
      text: "#0A2540",
      muted: "#697386"
    },
    typography: {
      headingFont: "Söhne",
      bodyFont: "Söhne",
      headingWeight: "Semibold",
      bodyWeight: "Regular"
    },
    description: "Financial services and software company"
  }
}

interface BrandConfig {
  name: string
  logo: string
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    text: string
    muted: string
  }
  typography: {
    headingFont: string
    bodyFont: string
    headingWeight: string
    bodyWeight: string
  }
  description?: string
}

interface BrandPanelProps {
  isOpen: boolean
  onClose: () => void
  onApplyBrand: (brand: BrandConfig) => void
  currentBrand?: BrandConfig | null
}

export function BrandPanel({ isOpen, onClose, onApplyBrand, currentBrand }: BrandPanelProps) {
  const [activeTab, setActiveTab] = useState("presets")
  const [selectedBrand, setSelectedBrand] = useState<string | null>(currentBrand?.name?.toLowerCase() || null)
  const [isApplying, setIsApplying] = useState(false)
  const [designSystemUrl, setDesignSystemUrl] = useState("")
  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState<string[]>([])
  
  // Custom brand state
  const [customBrand, setCustomBrand] = useState<BrandConfig>({
    name: "Custom Brand",
    logo: "",
    colors: {
      primary: "#3B82F6",
      secondary: "#1F2937",
      accent: "#10B981",
      background: "#FFFFFF",
      text: "#111827",
      muted: "#6B7280"
    },
    typography: {
      headingFont: "Inter",
      bodyFont: "Inter",
      headingWeight: "Bold",
      bodyWeight: "Regular"
    }
  })

  const handleApplyBrand = async (brandKey: string) => {
    setIsApplying(true)
    setSelectedBrand(brandKey)
    
    // Simulate applying brand
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const brand = PRESET_BRANDS[brandKey as keyof typeof PRESET_BRANDS]
    onApplyBrand(brand)
    setIsApplying(false)
  }

  const handleImportDesignSystem = async () => {
    if (!designSystemUrl) return
    
    setIsImporting(true)
    setImportProgress([])

    const steps = [
      "Connecting to design system...",
      "Fetching color tokens...",
      "Extracting typography styles...",
      "Downloading logo assets...",
      "Parsing component patterns...",
      "Building brand configuration..."
    ]

    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 800))
      setImportProgress(prev => [...prev, step])
    }

    await new Promise(resolve => setTimeout(resolve, 500))
    
    // Simulate imported brand
    const importedBrand: BrandConfig = {
      name: "Imported Brand",
      logo: "https://via.placeholder.com/120x40",
      colors: {
        primary: "#6366F1",
        secondary: "#1E1B4B",
        accent: "#A5B4FC",
        background: "#FFFFFF",
        text: "#1E1B4B",
        muted: "#64748B"
      },
      typography: {
        headingFont: "Inter",
        bodyFont: "Inter",
        headingWeight: "Semibold",
        bodyWeight: "Regular"
      },
      description: `Imported from ${designSystemUrl}`
    }

    onApplyBrand(importedBrand)
    setIsImporting(false)
    setImportProgress([])
  }

  const handleApplyCustomBrand = () => {
    setIsApplying(true)
    setTimeout(() => {
      onApplyBrand(customBrand)
      setIsApplying(false)
    }, 800)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 fade-in duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Palette className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Brand & Design System</h2>
              <p className="text-sm text-gray-500">Apply your brand identity to the layout</p>
            </div>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-6 pt-4">
            <TabsList className="w-full grid grid-cols-3 bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="presets" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
                Preset Brands
              </TabsTrigger>
              <TabsTrigger value="import" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
                Import System
              </TabsTrigger>
              <TabsTrigger value="custom" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
                Custom
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Presets Tab */}
          <TabsContent value="presets" className="mt-0">
            <ScrollArea className="h-[400px]">
              <div className="p-6 space-y-4">
                {Object.entries(PRESET_BRANDS).map(([key, brand]) => (
                  <div
                    key={key}
                    className={cn(
                      "relative p-4 rounded-xl border-2 transition-all cursor-pointer hover:shadow-md",
                      selectedBrand === key 
                        ? "border-violet-500 bg-violet-50/50" 
                        : "border-gray-200 hover:border-gray-300"
                    )}
                    onClick={() => setSelectedBrand(key)}
                  >
                    {selectedBrand === key && (
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-violet-500 flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                    
                    <div className="flex items-start gap-4">
                      {/* Logo Preview */}
                      <div className="w-16 h-16 rounded-lg bg-gray-100 flex items-center justify-center p-2 shrink-0">
                        {key === "nubank" ? (
                          <div className="w-10 h-10 rounded-full" style={{ backgroundColor: brand.colors.primary }} />
                        ) : (
                          <div 
                            className="w-full h-full rounded flex items-center justify-center text-xs font-bold"
                            style={{ backgroundColor: brand.colors.primary, color: "#fff" }}
                          >
                            {brand.name.substring(0, 2).toUpperCase()}
                          </div>
                        )}
                      </div>

                      {/* Brand Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900">{brand.name}</h3>
                        <p className="text-sm text-gray-500 mt-0.5">{brand.description}</p>
                        
                        {/* Color Swatches */}
                        <div className="flex items-center gap-1.5 mt-3">
                          {Object.entries(brand.colors).slice(0, 4).map(([colorKey, color]) => (
                            <div
                              key={colorKey}
                              className="w-6 h-6 rounded-full border border-gray-200 shadow-sm"
                              style={{ backgroundColor: color }}
                              title={colorKey}
                            />
                          ))}
                          <span className="text-xs text-gray-400 ml-1">+{Object.keys(brand.colors).length - 4}</span>
                        </div>

                        {/* Typography Preview */}
                        <div className="flex items-center gap-2 mt-2">
                          <Type className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-xs text-gray-500">
                            {brand.typography.headingFont} / {brand.typography.bodyFont}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Apply Button */}
                    {selectedBrand === key && (
                      <Button
                        className="w-full mt-4 bg-violet-600 hover:bg-violet-700 text-white"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleApplyBrand(key)
                        }}
                        disabled={isApplying}
                      >
                        {isApplying ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Applying brand...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Apply {brand.name} Brand
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Import Tab */}
          <TabsContent value="import" className="mt-0">
            <div className="p-6 space-y-6">
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">
                  Design System URL
                </label>
                <p className="text-sm text-gray-500">
                  Connect to your existing design system (Figma, Storybook, or custom JSON)
                </p>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="https://figma.com/file/... or storybook URL"
                      value={designSystemUrl}
                      onChange={(e) => setDesignSystemUrl(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button
                    onClick={handleImportDesignSystem}
                    disabled={!designSystemUrl || isImporting}
                    className="bg-violet-600 hover:bg-violet-700 text-white"
                  >
                    {isImporting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Import
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Import Progress */}
              {isImporting && (
                <div className="space-y-2 p-4 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 text-violet-600 animate-spin" />
                    <span className="text-sm font-medium text-gray-700">Importing design system...</span>
                  </div>
                  <div className="space-y-1 mt-3">
                    {importProgress.map((step, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600 animate-in slide-in-from-bottom-1">
                        <Check className="w-3.5 h-3.5 text-green-500" />
                        {step}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Supported Platforms */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-700">Supported Platforms</h4>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { name: "Figma", icon: "F", color: "#F24E1E" },
                    { name: "Storybook", icon: "S", color: "#FF4785" },
                    { name: "Style Dictionary", icon: "SD", color: "#00C7B7" },
                    { name: "Tokens Studio", icon: "T", color: "#5DAFFC" }
                  ].map((platform) => (
                    <div
                      key={platform.name}
                      className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:border-gray-300 cursor-pointer transition-colors"
                    >
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: platform.color }}
                      >
                        {platform.icon}
                      </div>
                      <div className="flex-1">
                        <span className="text-sm font-medium text-gray-900">{platform.name}</span>
                      </div>
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Custom Tab */}
          <TabsContent value="custom" className="mt-0">
            <ScrollArea className="h-[400px]">
              <div className="p-6 space-y-6">
                {/* Logo Upload */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Brand Logo</label>
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-20 rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center bg-gray-50 hover:bg-gray-100 cursor-pointer transition-colors">
                      {customBrand.logo ? (
                        <img src={customBrand.logo || "/placeholder.svg"} alt="Logo" className="w-full h-full object-contain p-2" />
                      ) : (
                        <ImageIcon className="w-8 h-8 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <Input
                        placeholder="Logo URL or upload"
                        value={customBrand.logo}
                        onChange={(e) => setCustomBrand(prev => ({ ...prev, logo: e.target.value }))}
                      />
                      <p className="text-xs text-gray-500 mt-1">SVG, PNG or JPG (max 2MB)</p>
                    </div>
                  </div>
                </div>

                {/* Brand Name */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Brand Name</label>
                  <Input
                    value={customBrand.name}
                    onChange={(e) => setCustomBrand(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Your brand name"
                  />
                </div>

                {/* Colors */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Brand Colors</label>
                  <div className="grid grid-cols-3 gap-3">
                    {Object.entries(customBrand.colors).map(([key, value]) => (
                      <div key={key} className="space-y-1.5">
                        <label className="text-xs text-gray-500 capitalize">{key}</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={value}
                            onChange={(e) => setCustomBrand(prev => ({
                              ...prev,
                              colors: { ...prev.colors, [key]: e.target.value }
                            }))}
                            className="w-8 h-8 rounded cursor-pointer border border-gray-200"
                          />
                          <Input
                            value={value}
                            onChange={(e) => setCustomBrand(prev => ({
                              ...prev,
                              colors: { ...prev.colors, [key]: e.target.value }
                            }))}
                            className="h-8 text-xs font-mono"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Typography */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Typography</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs text-gray-500">Heading Font</label>
                      <Input
                        value={customBrand.typography.headingFont}
                        onChange={(e) => setCustomBrand(prev => ({
                          ...prev,
                          typography: { ...prev.typography, headingFont: e.target.value }
                        }))}
                        placeholder="Inter, Roboto..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs text-gray-500">Body Font</label>
                      <Input
                        value={customBrand.typography.bodyFont}
                        onChange={(e) => setCustomBrand(prev => ({
                          ...prev,
                          typography: { ...prev.typography, bodyFont: e.target.value }
                        }))}
                        placeholder="Inter, Roboto..."
                      />
                    </div>
                  </div>
                </div>

                {/* Preview */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Preview</label>
                  <div 
                    className="p-6 rounded-xl border border-gray-200"
                    style={{ backgroundColor: customBrand.colors.background }}
                  >
                    <h3 
                      className="text-2xl font-bold mb-2"
                      style={{ color: customBrand.colors.text }}
                    >
                      {customBrand.name}
                    </h3>
                    <p 
                      className="text-sm mb-4"
                      style={{ color: customBrand.colors.muted }}
                    >
                      This is how your brand will look when applied to the layout.
                    </p>
                    <button
                      className="px-4 py-2 rounded-lg text-sm font-medium text-white"
                      style={{ backgroundColor: customBrand.colors.primary }}
                    >
                      Primary Button
                    </button>
                  </div>
                </div>

                {/* Apply Button */}
                <Button
                  className="w-full bg-violet-600 hover:bg-violet-700 text-white"
                  onClick={handleApplyCustomBrand}
                  disabled={isApplying}
                >
                  {isApplying ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Applying brand...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Apply Custom Brand
                    </>
                  )}
                </Button>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* Current Brand Footer */}
        {currentBrand && (
          <div className="px-6 py-4 border-t border-gray-100 bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold"
                  style={{ backgroundColor: currentBrand.colors.primary }}
                >
                  {currentBrand.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Current: {currentBrand.name}</p>
                  <p className="text-xs text-gray-500">Applied to all components</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {Object.values(currentBrand.colors).slice(0, 4).map((color, i) => (
                  <div
                    key={i}
                    className="w-4 h-4 rounded-full border border-white shadow-sm"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

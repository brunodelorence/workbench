"use client"

import React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeftRight, Maximize2, ZoomIn, ZoomOut, ExternalLink, RefreshCw } from "lucide-react"

interface CompareViewProps {
  originalUrl?: string
}

export function CompareView({ originalUrl = "https://unimal.jp/" }: CompareViewProps) {
  const [sliderPosition, setSliderPosition] = useState(50)
  const [isDragging, setIsDragging] = useState(false)
  const [zoom, setZoom] = useState(100)
  const [isLoadingOriginal, setIsLoadingOriginal] = useState(true)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const percentage = (x / rect.width) * 100
    setSliderPosition(Math.max(0, Math.min(100, percentage)))
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Extract domain name from URL for display
  const getDomainName = (url: string) => {
    try {
      const urlObj = new URL(url)
      return urlObj.hostname
    } catch {
      return url
    }
  }

  return (
    <div className="h-full flex flex-col bg-gray-100">
      {/* Toolbar */}
      <div className="h-12 bg-white border-b border-gray-200 flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span className="text-gray-600">Original ({getDomainName(originalUrl)})</span>
            <a 
              href={originalUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-gray-600"
            >
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <ArrowLeftRight className="w-4 h-4 text-gray-400" />
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span className="text-gray-600">New Design (V1)</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setZoom(Math.max(50, zoom - 10))}
            className="bg-transparent"
          >
            <ZoomOut className="w-4 h-4" />
          </Button>
          <span className="text-sm text-gray-600 w-12 text-center">{zoom}%</span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setZoom(Math.min(150, zoom + 10))}
            className="bg-transparent"
          >
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" className="bg-transparent">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Compare Area */}
      <div 
        className="flex-1 relative overflow-hidden cursor-ew-resize"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Original (Left) - Iframe of the original site */}
        <div 
          className="absolute inset-0 overflow-hidden"
          style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
        >
          <div 
            className="w-full h-full bg-white origin-top-left"
            style={{ transform: `scale(${zoom / 100})` }}
          >
            {/* Loading state */}
            {isLoadingOriginal && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
                <div className="flex flex-col items-center gap-3">
                  <RefreshCw className="w-8 h-8 text-gray-400 animate-spin" />
                  <span className="text-sm text-gray-500">Loading {getDomainName(originalUrl)}...</span>
                </div>
              </div>
            )}
            
            {/* Iframe for the original site */}
            <iframe
              src={originalUrl}
              className="w-full h-full border-0"
              style={{ 
                width: `${10000 / zoom}%`,
                height: `${10000 / zoom}%`,
                pointerEvents: 'none'
              }}
              title={`Original site: ${originalUrl}`}
              onLoad={() => setIsLoadingOriginal(false)}
              sandbox="allow-scripts allow-same-origin"
            />
          </div>
          
          {/* Label */}
          <div className="absolute top-4 left-4 px-3 py-1.5 bg-red-500 text-white text-xs font-medium rounded-full shadow-lg z-20">
            Original
          </div>
        </div>

        {/* New Design (Right) */}
        <div 
          className="absolute inset-0 overflow-hidden"
          style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
        >
          <div 
            className="w-full h-full bg-gradient-to-br from-blue-50/50 via-white to-cyan-50/50 origin-top-right"
            style={{ transform: `scale(${zoom / 100})` }}
          >
            <div className="min-h-full" style={{ width: `${10000 / zoom}%` }}>
              {/* New Header */}
              <header className="flex items-center justify-between px-12 py-4">
                <div className="text-xl font-bold text-gray-900">
                  unimal<span className="text-gray-400">.</span>
                </div>
                <nav className="flex items-center gap-8">
                  <span className="text-sm text-gray-600 hover:text-gray-900">Enterprise</span>
                  <span className="text-sm text-gray-600 hover:text-gray-900">Pricing</span>
                  <span className="text-sm text-gray-600 hover:text-gray-900">Docs</span>
                  <span className="text-sm text-gray-600 hover:text-gray-900">FAQ</span>
                  <span className="text-sm text-gray-900 font-medium">Sign in</span>
                </nav>
              </header>

              {/* Decorative circles */}
              <div className="absolute top-20 left-[15%] w-3 h-3 rounded-full border-2 border-cyan-300" />
              <div className="absolute top-40 right-[10%] w-3 h-3 rounded-full border-2 border-cyan-300" />
              <div className="absolute top-60 right-[15%] w-3 h-3 rounded-full border-2 border-cyan-300" />

              {/* New Hero */}
              <div className="flex flex-col items-center justify-center px-8 py-12">
                <h1 className="text-5xl font-medium text-gray-700 text-center leading-tight max-w-lg px-4 py-2">
                  Save time &<br />money with<br />Unimal
                </h1>
                <p className="mt-6 text-gray-500 text-center">
                  Savings, visibility, and infrastructure guardrails.<br />
                  One automated platform.
                </p>
                <button className="mt-8 px-6 py-3 bg-gray-900 text-white text-sm font-medium rounded-lg flex items-center gap-2">
                  <span className="text-yellow-400">{">"}</span>
                  Book a demo
                </button>

                {/* New Dashboard */}
                <div className="mt-12 w-full max-w-4xl bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100">
                  <div className="flex">
                    <div className="w-48 border-r border-gray-100 p-4">
                      <div className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 bg-gray-50 rounded">
                        All Accounts
                      </div>
                      <div className="mt-4 space-y-1">
                        <div className="flex items-center gap-2 px-3 py-2 text-sm text-gray-900 bg-gray-100 rounded font-medium">
                          Dashboard
                        </div>
                        <div className="flex items-center gap-2 px-3 py-2 text-sm text-gray-500">
                          Guardrails
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-lg font-semibold text-gray-900">Dashboard</h2>
                        <div className="flex items-center gap-1 text-xs">
                          <span className="px-3 py-1 bg-gray-900 text-white rounded">1M</span>
                          <span className="px-3 py-1 text-gray-500">3M</span>
                          <span className="px-3 py-1 text-gray-500">6M</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <span className="text-sm font-medium text-gray-700">Overview</span>
                          <div className="flex gap-4 mt-3">
                            <div>
                              <div className="text-xl font-bold">$50,104</div>
                              <div className="text-xs text-gray-500">Net spend</div>
                            </div>
                            <div>
                              <div className="text-xl font-bold">$20,062</div>
                              <div className="text-xs text-gray-500">Saved</div>
                            </div>
                          </div>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <span className="text-sm font-medium text-gray-700">Budget</span>
                          <div className="flex gap-4 mt-3">
                            <div>
                              <div className="text-xl font-bold">$20K</div>
                              <div className="text-xs text-gray-500">$2,500 left</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Label */}
          <div className="absolute top-4 right-4 px-3 py-1.5 bg-green-500 text-white text-xs font-medium rounded-full shadow-lg z-20">
            New Design
          </div>
        </div>

        {/* Slider Handle */}
        <div 
          className="absolute top-0 bottom-0 w-1 bg-white shadow-lg cursor-ew-resize z-10"
          style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
          onMouseDown={() => setIsDragging(true)}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center border border-gray-200">
            <ArrowLeftRight className="w-5 h-5 text-gray-600" />
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="h-10 bg-white border-t border-gray-200 flex items-center justify-center text-sm text-gray-500">
        Drag the slider to compare the original and new design
      </div>
    </div>
  )
}

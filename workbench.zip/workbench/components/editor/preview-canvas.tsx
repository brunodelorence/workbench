"use client"

import React from "react"

import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { Sparkles, Wand2, Check, X, Loader2, ArrowRight, Zap, Shield, BarChart3, Users, Star, Play, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ElementStyles {
  fontFamily: string
  fontWeight: string
  fontSize: string
  lineHeight: string
  letterSpacing: string
  textAlign: string
  textDecoration: string
  color: string
  background: string
  marginX: string
  marginY: string
  paddingX: string
  paddingY: string
  gapX: string
  gapY: string
  borderStyle: string
  borderColor: string
}

interface LayoutSuggestion {
  id: string
  name: string
  description: string
  preview: React.ReactNode
  styles: Partial<ElementStyles>
}

type TemplateType = "marketing" | "saas" | "portfolio" | "ecommerce" | "dashboard"

interface PreviewCanvasProps {
  selectedElementId: string | null
  onSelectElement: (id: string | null) => void
  elementStyles: Record<string, ElementStyles>
  elementContent?: Record<string, string>
  currentTemplate?: TemplateType
  onApplyStyles?: (elementId: string, styles: Partial<ElementStyles>) => void
}

export function PreviewCanvas({ 
  selectedElementId, 
  onSelectElement, 
  elementStyles, 
  elementContent = {},
  currentTemplate = "marketing",
  onApplyStyles 
}: PreviewCanvasProps) {
  const [showAISuggestions, setShowAISuggestions] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [suggestions, setSuggestions] = useState<LayoutSuggestion[]>([])
  const [generationStep, setGenerationStep] = useState(0)
  const [selectedSuggestion, setSelectedSuggestion] = useState<string | null>(null)

  // Function to open AI suggestions manually
  const openAISuggestions = () => {
    if (!selectedElementId) return
    
    setShowAISuggestions(true)
    setIsGenerating(true)
    setGenerationStep(0)
    setSuggestions([])
    setSelectedSuggestion(null)

    const steps = [
      { delay: 500, step: 1 },
      { delay: 1200, step: 2 },
      { delay: 2000, step: 3 },
    ]

    steps.forEach(({ delay, step }) => {
      setTimeout(() => setGenerationStep(step), delay)
    })

    setTimeout(() => {
      setIsGenerating(false)
      setSuggestions(getSuggestionsForElement(selectedElementId))
    }, 2500)
  }

  useEffect(() => {
    if (!selectedElementId) {
      setShowAISuggestions(false)
      setSuggestions([])
    }
  }, [selectedElementId])

  const getSuggestionsForElement = (elementId: string): LayoutSuggestion[] => {
    // Return suggestions based on element type
    if (elementId.includes("heading") || elementId.includes("title")) {
      return [
        {
          id: "heading-bold",
          name: "Bold & Impactful",
          description: "Larger text with bold weight",
          preview: <div className="p-3 bg-gray-50 rounded-lg text-lg font-bold text-gray-900 text-center">Bold Style</div>,
          styles: { fontWeight: "Bold", fontSize: "5xl", color: "text-gray-900" }
        },
        {
          id: "heading-gradient",
          name: "Gradient Accent",
          description: "Modern gradient style",
          preview: <div className="p-3 bg-gray-50 rounded-lg text-lg font-semibold bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent text-center">Gradient Style</div>,
          styles: { fontWeight: "Semibold", color: "text-blue-600" }
        },
        {
          id: "heading-minimal",
          name: "Clean Minimal",
          description: "Light weight for elegance",
          preview: <div className="p-3 bg-gray-50 rounded-lg text-lg font-light text-gray-600 text-center tracking-wide">Minimal Style</div>,
          styles: { fontWeight: "Light", color: "text-gray-500", letterSpacing: "0.05em" }
        }
      ]
    }
    
    if (elementId.includes("button") || elementId.includes("cta")) {
      return [
        {
          id: "button-primary",
          name: "Primary Blue",
          description: "High contrast blue button",
          preview: <div className="p-3 bg-gray-50 rounded-lg flex justify-center"><div className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg">Button</div></div>,
          styles: { background: "bg-blue-600", color: "text-white" }
        },
        {
          id: "button-gradient",
          name: "Gradient CTA",
          description: "Eye-catching gradient",
          preview: <div className="p-3 bg-gray-50 rounded-lg flex justify-center"><div className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm font-medium rounded-lg">Button</div></div>,
          styles: { background: "bg-blue-600", color: "text-white" }
        },
        {
          id: "button-dark",
          name: "Dark Style",
          description: "Professional dark look",
          preview: <div className="p-3 bg-gray-50 rounded-lg flex justify-center"><div className="px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg">Button</div></div>,
          styles: { background: "bg-gray-900", color: "text-white" }
        }
      ]
    }

    return [
      {
        id: "style-1",
        name: "Option A",
        description: "Alternative style",
        preview: <div className="p-3 bg-gray-50 rounded-lg text-sm text-center">Style A</div>,
        styles: {}
      },
      {
        id: "style-2",
        name: "Option B",
        description: "Another variant",
        preview: <div className="p-3 bg-gray-50 rounded-lg text-sm text-center">Style B</div>,
        styles: {}
      }
    ]
  }

  const handleApplySuggestion = (suggestion: LayoutSuggestion) => {
    setSelectedSuggestion(suggestion.id)
    if (selectedElementId && onApplyStyles) {
      onApplyStyles(selectedElementId, suggestion.styles)
    }
  }

  const getElementStylesCSS = (elementId: string) => {
    const styles = elementStyles[elementId]
    if (!styles) return {}
    
    const styleMap: Record<string, string | undefined> = {}
    
    if (styles.fontFamily !== "default") styleMap.fontFamily = styles.fontFamily
    
    const weightMap: Record<string, string> = { "Light": "300", "Regular": "400", "Medium": "500", "Semibold": "600", "Bold": "700" }
    if (styles.fontWeight && weightMap[styles.fontWeight]) styleMap.fontWeight = weightMap[styles.fontWeight]
    
    const sizeMap: Record<string, string> = { "xs": "0.75rem", "sm": "0.875rem", "base": "1rem", "lg": "1.125rem", "xl": "1.25rem", "2xl": "1.5rem", "3xl": "1.875rem", "4xl": "2.25rem", "5xl": "3rem", "6xl": "3.75rem" }
    if (styles.fontSize && sizeMap[styles.fontSize]) styleMap.fontSize = sizeMap[styles.fontSize]
    
    if (styles.lineHeight) styleMap.lineHeight = styles.lineHeight
    if (styles.letterSpacing) styleMap.letterSpacing = styles.letterSpacing
    if (styles.textAlign && styles.textAlign !== "undo") styleMap.textAlign = styles.textAlign
    
    return styleMap
  }

  const getColorClass = (elementId: string) => {
    const styles = elementStyles[elementId]
    if (!styles) return ""
    return styles.color !== "text-gray-700" ? styles.color : ""
  }

  const getBackgroundClass = (elementId: string) => {
    const styles = elementStyles[elementId]
    if (!styles) return ""
    return styles.background !== "Default" ? styles.background : ""
  }

  const SelectableElement = ({ 
    id, 
    children, 
    className = "",
    defaultClassName = ""
  }: { 
    id: string
    children: React.ReactNode
    className?: string
    defaultClassName?: string
  }) => (
    <div
      className={cn(
        "relative cursor-pointer transition-all",
        selectedElementId === id && "ring-2 ring-blue-500 ring-offset-2",
        className
      )}
      onClick={(e) => {
        e.stopPropagation()
        onSelectElement(id)
      }}
    >
      {selectedElementId === id && (
        <>
          <div className="absolute -top-6 left-0 px-2 py-0.5 bg-blue-500 text-white text-xs font-medium rounded z-10">
            {id}
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation()
              openAISuggestions()
            }}
            className="absolute -top-6 right-0 p-1 bg-gradient-to-r from-violet-500 to-purple-500 text-white rounded hover:from-violet-600 hover:to-purple-600 transition-colors z-10"
            title="AI Suggestions"
          >
            <Sparkles className="w-3 h-3" />
          </button>
        </>
      )}
      <div className={cn(defaultClassName, getColorClass(id), getBackgroundClass(id))} style={getElementStylesCSS(id)}>
        {children}
      </div>
    </div>
  )

  return (
    <div className="relative w-full h-full overflow-auto bg-white">
      {/* AI Suggestions Popover */}
      {showAISuggestions && selectedElementId && (
        <div className="absolute top-4 right-4 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-gradient-to-r from-violet-50 to-purple-50">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-gradient-to-r from-violet-500 to-purple-500 rounded-lg">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-medium text-gray-900 text-sm">AI Layout Suggestions</span>
            </div>
            <button onClick={() => setShowAISuggestions(false)} className="p-1 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>

          <div className="p-4">
            {isGenerating ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-violet-500 animate-spin" />
                  <span className="text-sm text-gray-600">Analyzing element...</span>
                </div>
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className={cn("flex items-center gap-2 text-xs transition-all duration-300", generationStep >= i ? "text-gray-700" : "text-gray-300")}>
                      <div className={cn("w-4 h-4 rounded-full flex items-center justify-center text-[10px]", generationStep >= i ? "bg-green-500 text-white" : "bg-gray-200")}>
                        {generationStep >= i ? <Check className="w-3 h-3" /> : i}
                      </div>
                      {i === 1 && "Reading component structure"}
                      {i === 2 && "Analyzing user traffic patterns"}
                      {i === 3 && "Generating optimized layouts"}
                    </div>
                  ))}
                </div>
                <div className="space-y-3 mt-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse"><div className="h-20 bg-gray-100 rounded-lg" /></div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-gray-500 mb-3">Based on your user traffic, here are optimized layouts:</p>
                {suggestions.map((suggestion) => (
                  <div 
                    key={suggestion.id}
                    className={cn("border rounded-lg overflow-hidden transition-all cursor-pointer", selectedSuggestion === suggestion.id ? "border-violet-500 ring-2 ring-violet-100" : "border-gray-200 hover:border-violet-300")}
                    onClick={() => handleApplySuggestion(suggestion)}
                  >
                    {suggestion.preview}
                    <div className="p-3 border-t border-gray-100 bg-white">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-sm text-gray-900">{suggestion.name}</div>
                          <div className="text-xs text-gray-500">{suggestion.description}</div>
                        </div>
                        {selectedSuggestion === suggestion.id && (
                          <div className="p-1 bg-violet-500 rounded-full"><Check className="w-3 h-3 text-white" /></div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {selectedSuggestion && (
                  <Button className="w-full mt-2 bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600" size="sm" onClick={() => setShowAISuggestions(false)}>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Applied to canvas
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modern AI Business Landing Page */}
      <div className="min-h-full">
        {/* Navigation */}
        <SelectableElement id="nav" defaultClassName="flex items-center justify-between px-8 lg:px-16 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-violet-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">NeuralFlow</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Products</a>
            <a className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Solutions</a>
            <a className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Pricing</a>
            <a className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Resources</a>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-gray-600 bg-transparent">Sign in</Button>
            <Button size="sm" className="bg-gray-900 hover:bg-gray-800 text-white">Get Started</Button>
          </div>
        </SelectableElement>

        {/* Hero Section */}
        <section className="px-8 lg:px-16 py-20 bg-gradient-to-b from-gray-50 to-white">
          <div className="max-w-5xl mx-auto text-center">
            <SelectableElement id="hero-badge" defaultClassName="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 border border-blue-100 rounded-full text-sm text-blue-700 mb-6">
              <Sparkles className="w-4 h-4" />
              Powered by GPT-4 & Claude 3
              <ChevronRight className="w-4 h-4" />
            </SelectableElement>

            <SelectableElement id="hero-heading" defaultClassName="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Build AI-Powered Apps<br />
              <span className="bg-gradient-to-r from-blue-600 via-violet-600 to-purple-600 bg-clip-text text-transparent">10x Faster</span>
            </SelectableElement>

            <SelectableElement id="hero-subtitle" defaultClassName="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
              The complete platform for building, deploying, and scaling intelligent applications. From prototype to production in minutes, not months.
            </SelectableElement>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <SelectableElement id="hero-cta-primary" defaultClassName="px-8 py-4 bg-gray-900 hover:bg-gray-800 text-white font-medium rounded-xl flex items-center gap-2 transition-colors">
                Start Building Free
                <ArrowRight className="w-5 h-5" />
              </SelectableElement>
              <SelectableElement id="hero-cta-secondary" defaultClassName="px-8 py-4 bg-white border border-gray-200 hover:border-gray-300 text-gray-700 font-medium rounded-xl flex items-center gap-2 transition-colors">
                <Play className="w-5 h-5" />
                Watch Demo
              </SelectableElement>
            </div>

            <SelectableElement id="hero-social-proof" defaultClassName="flex items-center justify-center gap-8 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1,2,3,4,5].map((i) => (
                    <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 border-2 border-white" />
                  ))}
                </div>
                <span className="font-medium text-gray-900">10,000+</span> developers
              </div>
              <div className="flex items-center gap-1">
                {[1,2,3,4,5].map((i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
                <span className="ml-1 font-medium text-gray-900">4.9/5</span> rating
              </div>
            </SelectableElement>
          </div>
        </section>

        {/* Logos Section */}
        <SelectableElement id="logos-section" defaultClassName="px-8 lg:px-16 py-12 border-y border-gray-100 bg-gray-50/50">
          <div className="max-w-5xl mx-auto">
            <p className="text-center text-sm text-gray-500 mb-8">Trusted by innovative teams worldwide</p>
            <div className="flex items-center justify-center gap-12 flex-wrap opacity-60">
              {["Google", "Microsoft", "Stripe", "Notion", "OpenAI", "Anthropic"].map((company) => (
                <div key={company} className="text-xl font-bold text-gray-400">{company}</div>
              ))}
            </div>
          </div>
        </SelectableElement>

        {/* Features Section */}
        <section className="px-8 lg:px-16 py-20">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-16">
              <SelectableElement id="features-title" defaultClassName="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Everything you need to build with AI
              </SelectableElement>
              <SelectableElement id="features-subtitle" defaultClassName="text-lg text-gray-600 max-w-2xl mx-auto">
                Powerful features that help you ship faster and scale effortlessly
              </SelectableElement>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Zap, title: "Lightning Fast", desc: "Sub-100ms response times with edge deployment and intelligent caching.", color: "blue" },
                { icon: Shield, title: "Enterprise Security", desc: "SOC 2 compliant with end-to-end encryption and data isolation.", color: "green" },
                { icon: BarChart3, title: "Real-time Analytics", desc: "Monitor performance, usage patterns, and model accuracy in real-time.", color: "purple" }
              ].map((feature, idx) => (
                <SelectableElement 
                  key={idx}
                  id={`feature-card-${idx}`} 
                  defaultClassName="p-6 bg-white border border-gray-200 rounded-2xl hover:shadow-lg hover:border-gray-300 transition-all group"
                >
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center mb-4",
                    feature.color === "blue" && "bg-blue-100 text-blue-600",
                    feature.color === "green" && "bg-green-100 text-green-600",
                    feature.color === "purple" && "bg-purple-100 text-purple-600"
                  )}>
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{feature.desc}</p>
                </SelectableElement>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <SelectableElement id="cta-section" defaultClassName="px-8 lg:px-16 py-20 bg-gray-900">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">Ready to transform your workflow?</h2>
            <p className="text-lg text-gray-400 mb-8">Join thousands of developers building the future with AI</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 font-medium px-8">
                Get Started Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-gray-700 text-white hover:bg-gray-800 font-medium px-8 bg-transparent">
                Talk to Sales
              </Button>
            </div>
          </div>
        </SelectableElement>

        {/* Footer */}
        <SelectableElement id="footer" defaultClassName="px-8 lg:px-16 py-12 border-t border-gray-200">
          <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-600 to-violet-600 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold text-gray-900">NeuralFlow</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-gray-600">
              <a className="hover:text-gray-900">Privacy</a>
              <a className="hover:text-gray-900">Terms</a>
              <a className="hover:text-gray-900">Documentation</a>
              <a className="hover:text-gray-900">Support</a>
            </div>
            <p className="text-sm text-gray-500">© 2024 NeuralFlow. All rights reserved.</p>
          </div>
        </SelectableElement>
      </div>
    </div>
  )
}

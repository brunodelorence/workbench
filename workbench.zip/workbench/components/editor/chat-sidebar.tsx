"use client"

import React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import { 
  Paperclip, 
  Smile, 
  Send, 
  ChevronDown,
  ChevronRight,
  MoreHorizontal,
  Wrench,
  Globe,
  Check,
  Palette,
  Layout,
  Type,
  Sparkles
} from "lucide-react"
import { BrandStyleModal, type BrandStyles } from "./brand-style-modal"

export interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  colors?: string[]
  createdUI?: string
  issues?: string
}

export type TemplateType = "marketing" | "saas" | "portfolio" | "ecommerce" | "dashboard"

interface ChatSidebarProps {
  messages: ChatMessage[]
  onSendMessage: (message: string) => void
  isProcessing?: boolean
  redesignUrl?: string
  onOpenBrand?: () => void
  onTemplateChange?: (template: TemplateType) => void
  currentTemplate?: TemplateType
  onApplyBrandStyles?: (styles: BrandStyles) => void
  hasBrandStyle?: boolean
}

const templates: { id: TemplateType; name: string; description: string }[] = [
  { id: "marketing", name: "Marketing Agency", description: "Professional marketing landing page" },
  { id: "saas", name: "SaaS Product", description: "Modern SaaS product showcase" },
  { id: "portfolio", name: "Portfolio", description: "Creative portfolio layout" },
  { id: "ecommerce", name: "E-commerce", description: "Product-focused store design" },
  { id: "dashboard", name: "Dashboard", description: "Admin dashboard interface" }
]

export function ChatSidebar({ 
  messages, 
  onSendMessage, 
  isProcessing = false,
  redesignUrl = "https://unimal.jp/",
  onOpenBrand,
  onTemplateChange,
  currentTemplate = "marketing",
  onApplyBrandStyles,
  hasBrandStyle = false
}: ChatSidebarProps) {
  const [inputValue, setInputValue] = useState("")
  const [expandedUI, setExpandedUI] = useState<string | null>(null)
  const [showTemplateSelector, setShowTemplateSelector] = useState(false)
  const [showBrandModal, setShowBrandModal] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const templateSelectorRef = useRef<HTMLDivElement>(null)

  const actionSuggestions = [
    { icon: <Layout className="w-3.5 h-3.5" />, label: "Change to card layout" },
    { icon: <Type className="w-3.5 h-3.5" />, label: "Make heading bigger" },
    { icon: <Palette className="w-3.5 h-3.5" />, label: "Change button to blue" },
    { icon: <Sparkles className="w-3.5 h-3.5" />, label: "Add animation" },
  ]

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Close template selector when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (templateSelectorRef.current && !templateSelectorRef.current.contains(event.target as Node)) {
        setShowTemplateSelector(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleSend = () => {
    if (inputValue.trim() && !isProcessing) {
      onSendMessage(inputValue.trim())
      setInputValue("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleTemplateSelect = (templateId: TemplateType) => {
    onTemplateChange?.(templateId)
    setShowTemplateSelector(false)
  }

  const handleBrandStyleApply = (styles: BrandStyles) => {
    onApplyBrandStyles?.(styles)
    setShowBrandModal(false)
  }

  const currentTemplateData = templates.find(t => t.id === currentTemplate)

  return (
    <>
      <div className="flex flex-col h-full overflow-hidden">
        {/* Scrollable Chat Messages */}
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className="space-y-3">
                {message.role === "user" ? (
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex-shrink-0 flex items-center justify-center">
                      <span className="text-white text-xs font-medium">U</span>
                    </div>
                    <div className="flex-1 pt-0.5 min-w-0">
                      <p className="text-sm text-gray-800 leading-relaxed break-words">{message.content}</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 pl-0">
                    {/* Assistant message content */}
                    <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap break-words">
                      {message.content}
                    </div>

                    {/* Brand Colors */}
                    {message.colors && message.colors.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm text-gray-700">I will follow the primary colors of your brand.</p>
                        <div className="flex flex-wrap gap-2">
                          {message.colors.map((color, idx) => (
                            <div key={idx} className="flex items-center gap-1.5 px-2 py-1 bg-gray-50 rounded-md border border-gray-100">
                              <div 
                                className="w-3 h-3 rounded-sm flex-shrink-0" 
                                style={{ backgroundColor: color }}
                              />
                              <span className="text-xs text-gray-600">{color}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Created UI Collapse */}
                    {message.createdUI && (
                      <div className="border border-gray-200 rounded-lg overflow-hidden">
                        <button
                          onClick={() => setExpandedUI(expandedUI === message.id ? null : message.id)}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            {expandedUI === message.id ? (
                              <ChevronDown className="w-4 h-4 text-gray-400" />
                            ) : (
                              <ChevronRight className="w-4 h-4 text-gray-400" />
                            )}
                            <span className="text-sm font-medium text-gray-700">
                              {message.createdUI}
                            </span>
                          </div>
                          <MoreHorizontal className="w-4 h-4 text-gray-400" />
                        </button>
                        {expandedUI === message.id && (
                          <div className="px-3 py-2 border-t border-gray-100 bg-gray-50">
                            <p className="text-xs text-gray-500">UI component created and applied to canvas.</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Issues Status */}
                    {message.issues !== undefined && (
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Wrench className="w-4 h-4 flex-shrink-0" />
                        <span>{message.issues || "No issues found"}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {/* Processing indicator */}
            {isProcessing && (
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 animate-pulse flex-shrink-0" />
                <span>AI is thinking...</span>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Fixed Bottom Section */}
        <div className="flex-shrink-0 border-t border-gray-100 p-4 space-y-3 bg-white">
          {/* Action Suggestions */}
          <div className="space-y-2">
            <p className="text-xs text-gray-500">Action Suggestions</p>
            <div className="flex flex-wrap gap-2">
              {actionSuggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-700 bg-white border border-gray-200 rounded-full hover:bg-gray-50 transition-colors"
                  onClick={() => setInputValue(suggestion.label)}
                >
                  {suggestion.icon}
                  <span>{suggestion.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="border border-gray-200 rounded-xl overflow-hidden bg-white">
            <div className="relative">
              <textarea
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything..."
                className="w-full pl-4 pr-40 py-3 text-sm resize-none focus:outline-none min-h-[60px] max-h-[120px]"
                rows={2}
              />
              <div className="absolute top-3 right-3">
                <button 
                  onClick={() => setShowBrandModal(true)}
                  className={cn(
                    "flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md transition-colors cursor-pointer",
                    hasBrandStyle 
                      ? "bg-green-50 text-green-700 border border-green-200 hover:bg-green-100"
                      : "bg-gray-50 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                  )}
                >
                  {hasBrandStyle ? (
                    <>
                      <Check className="w-3 h-3" />
                      Brand style applied
                    </>
                  ) : (
                    <>
                      <Globe className="w-3 h-3" />
                      No brand style
                    </>
                  )}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between px-3 py-2 border-t border-gray-100 bg-gray-50/50">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon-sm" className="h-7 w-7 text-gray-400 hover:text-gray-600 bg-transparent">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon-sm" className="h-7 w-7 text-gray-400 hover:text-gray-600 bg-transparent">
                  <Smile className="w-4 h-4" />
                </Button>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className={cn(
                  "text-blue-600 hover:text-blue-700 hover:bg-blue-50 font-medium bg-transparent",
                  (!inputValue.trim() || isProcessing) && "opacity-50 cursor-not-allowed"
                )}
                onClick={handleSend}
                disabled={!inputValue.trim() || isProcessing}
              >
                Send
              </Button>
            </div>
          </div>

          {/* Template Selector */}
          <div className="relative" ref={templateSelectorRef}>
            <button 
              className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-800 transition-colors"
              onClick={() => setShowTemplateSelector(!showTemplateSelector)}
            >
              {currentTemplateData?.name || "Marketing Agency"} template
              <ChevronDown className={cn("w-4 h-4 transition-transform", showTemplateSelector && "rotate-180")} />
            </button>
            
            {/* Template Dropdown */}
            {showTemplateSelector && (
              <div className="absolute bottom-full left-0 mb-2 w-72 bg-white rounded-xl shadow-xl border border-gray-200 overflow-hidden z-50">
                <div className="p-3 border-b border-gray-100 bg-gray-50">
                  <p className="text-xs font-medium text-gray-700">Select a Template</p>
                  <p className="text-xs text-gray-500 mt-0.5">Changing will update the entire layout</p>
                </div>
                <div className="p-2 max-h-64 overflow-y-auto">
                  {templates.map((template) => (
                    <button
                      key={template.id}
                      className={cn(
                        "w-full flex items-center justify-between p-3 rounded-lg text-left transition-colors",
                        currentTemplate === template.id 
                          ? "bg-blue-50 border border-blue-200" 
                          : "hover:bg-gray-50"
                      )}
                      onClick={() => handleTemplateSelect(template.id)}
                    >
                      <div>
                        <p className={cn(
                          "text-sm font-medium",
                          currentTemplate === template.id ? "text-blue-700" : "text-gray-900"
                        )}>
                          {template.name}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">{template.description}</p>
                      </div>
                      {currentTemplate === template.id && (
                        <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Disclaimer */}
          <p className="text-xs text-gray-400 text-center">
            AI may make mistakes. Please use with discretion.
          </p>
        </div>
      </div>

      {/* Brand Style Modal */}
      <BrandStyleModal 
        isOpen={showBrandModal}
        onClose={() => setShowBrandModal(false)}
        onApply={handleBrandStyleApply}
      />
    </>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { 
  X, 
  Sparkles, 
  TrendingUp, 
  MousePointerClick, 
  Eye, 
  Clock, 
  ChevronRight,
  Check,
  Lightbulb,
  BarChart3,
  Zap
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Recommendation {
  id: string
  elementId: string
  elementName: string
  type: "low-engagement" | "high-bounce" | "slow-interaction" | "visibility"
  severity: "high" | "medium" | "low"
  title: string
  description: string
  metrics: {
    label: string
    value: string
    change?: string
    trend?: "up" | "down"
  }[]
  suggestions: {
    id: string
    title: string
    description: string
    preview: {
      property: string
      oldValue: string
      newValue: string
    }[]
    expectedImprovement: string
  }[]
}

interface RecommendationsPanelProps {
  isOpen: boolean
  onClose: () => void
  onApplySuggestion: (elementId: string, changes: { property: string; value: string }[]) => void
  selectedElementId: string | null
}

const mockRecommendations: Recommendation[] = [
  {
    id: "rec-1",
    elementId: "hero-button",
    elementName: "CTA Button - Book a demo",
    type: "low-engagement",
    severity: "high",
    title: "Low click-through rate detected",
    description: "I've identified that users are spending little time clicking on this button. The current engagement rate is 2.3%, which is below the industry average of 4.5%.",
    metrics: [
      { label: "Click Rate", value: "2.3%", change: "-1.2%", trend: "down" },
      { label: "Hover Time", value: "0.8s", change: "-0.4s", trend: "down" },
      { label: "Visibility", value: "89%", trend: "up" },
    ],
    suggestions: [
      {
        id: "sug-1a",
        title: "Increase button contrast",
        description: "Make the button more visually prominent with a brighter background color",
        preview: [
          { property: "background", oldValue: "bg-gray-900", newValue: "bg-blue-600" },
          { property: "fontSize", oldValue: "sm", newValue: "base" },
        ],
        expectedImprovement: "+45% click rate",
      },
      {
        id: "sug-1b",
        title: "Add urgency indicator",
        description: "Use a warmer color to create urgency and draw attention",
        preview: [
          { property: "background", oldValue: "bg-gray-900", newValue: "bg-orange-500" },
          { property: "fontWeight", oldValue: "Medium", newValue: "Semibold" },
        ],
        expectedImprovement: "+38% click rate",
      },
      {
        id: "sug-1c",
        title: "Increase button size",
        description: "Larger touch target improves mobile conversions",
        preview: [
          { property: "paddingX", oldValue: "24px", newValue: "32px" },
          { property: "paddingY", oldValue: "12px", newValue: "16px" },
          { property: "fontSize", oldValue: "sm", newValue: "lg" },
        ],
        expectedImprovement: "+32% click rate",
      },
    ],
  },
  {
    id: "rec-2",
    elementId: "hero-heading",
    elementName: "Hero Heading",
    type: "visibility",
    severity: "medium",
    title: "Heading visibility could be improved",
    description: "Users scroll past this element quickly. The average time spent viewing is 1.2 seconds, suggesting the message isn't capturing attention effectively.",
    metrics: [
      { label: "View Time", value: "1.2s", change: "-0.8s", trend: "down" },
      { label: "Scroll Depth", value: "34%", trend: "up" },
      { label: "Read Rate", value: "45%", change: "-12%", trend: "down" },
    ],
    suggestions: [
      {
        id: "sug-2a",
        title: "Increase heading size",
        description: "Larger text draws more attention and improves readability",
        preview: [
          { property: "fontSize", oldValue: "5xl", newValue: "6xl" },
          { property: "fontWeight", oldValue: "Medium", newValue: "Bold" },
        ],
        expectedImprovement: "+28% engagement",
      },
      {
        id: "sug-2b",
        title: "Add color emphasis",
        description: "Use brand color to highlight key words",
        preview: [
          { property: "color", oldValue: "text-gray-700", newValue: "text-gray-900" },
          { property: "fontWeight", oldValue: "Medium", newValue: "Semibold" },
        ],
        expectedImprovement: "+22% engagement",
      },
    ],
  },
  {
    id: "rec-3",
    elementId: "hero-subtitle",
    elementName: "Hero Subtitle",
    type: "slow-interaction",
    severity: "low",
    title: "Subtitle may be too subtle",
    description: "The supporting text has low contrast and may be overlooked by users scanning the page quickly.",
    metrics: [
      { label: "Read Rate", value: "32%", change: "-8%", trend: "down" },
      { label: "Engagement", value: "Low", trend: "down" },
    ],
    suggestions: [
      {
        id: "sug-3a",
        title: "Improve text contrast",
        description: "Darker text color improves readability",
        preview: [
          { property: "color", oldValue: "text-gray-500", newValue: "text-gray-700" },
          { property: "fontSize", oldValue: "base", newValue: "lg" },
        ],
        expectedImprovement: "+18% read rate",
      },
    ],
  },
]

export function RecommendationsPanel({ 
  isOpen, 
  onClose, 
  onApplySuggestion,
  selectedElementId 
}: RecommendationsPanelProps) {
  const [expandedRec, setExpandedRec] = useState<string | null>(null)
  const [selectedSuggestion, setSelectedSuggestion] = useState<string | null>(null)
  const [appliedSuggestions, setAppliedSuggestions] = useState<string[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(false)

  useEffect(() => {
    if (isOpen && !analysisComplete) {
      setIsAnalyzing(true)
      const timer = setTimeout(() => {
        setIsAnalyzing(false)
        setAnalysisComplete(true)
      }, 2500)
      return () => clearTimeout(timer)
    }
  }, [isOpen, analysisComplete])

  const handleApplySuggestion = (rec: Recommendation, suggestion: typeof rec.suggestions[0]) => {
    const changes = suggestion.preview.map(p => ({
      property: p.property,
      value: p.newValue
    }))
    onApplySuggestion(rec.elementId, changes)
    setAppliedSuggestions(prev => [...prev, suggestion.id])
    setSelectedSuggestion(suggestion.id)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "bg-red-100 text-red-700 border-red-200"
      case "medium": return "bg-amber-100 text-amber-700 border-amber-200"
      case "low": return "bg-blue-100 text-blue-700 border-blue-200"
      default: return "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "low-engagement": return <MousePointerClick className="size-4" />
      case "high-bounce": return <TrendingUp className="size-4" />
      case "slow-interaction": return <Clock className="size-4" />
      case "visibility": return <Eye className="size-4" />
      default: return <Lightbulb className="size-4" />
    }
  }

  if (!isOpen) return null

  return (
    <div className="w-[420px] border-l border-border bg-background flex flex-col h-full animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg">
            <Sparkles className="size-4 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-foreground">AI Recommendations</h2>
            <p className="text-xs text-muted-foreground">Based on user traffic analysis</p>
          </div>
        </div>
        <Button variant="ghost" size="icon-sm" onClick={onClose}>
          <X className="size-4" />
        </Button>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isAnalyzing ? (
          <div className="flex flex-col items-center justify-center h-80 gap-4 p-6">
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500/20 to-purple-600/20 animate-pulse" />
              <div className="absolute inset-0 flex items-center justify-center">
                <BarChart3 className="size-6 text-violet-600 animate-pulse" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <p className="text-sm font-medium text-foreground">Analyzing your components...</p>
              <p className="text-xs text-muted-foreground">
                Scanning user behavior patterns and engagement metrics
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-violet-500 animate-ping" />
              <span>Processing 3 components</span>
            </div>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {/* Summary */}
            <div className="p-3 rounded-lg bg-gradient-to-br from-violet-50 to-purple-50 border border-violet-100">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="size-4 text-violet-600" />
                <span className="text-sm font-medium text-violet-900">Analysis Complete</span>
              </div>
              <p className="text-xs text-violet-700">
                Found {mockRecommendations.length} opportunities to improve user engagement based on your traffic data.
              </p>
            </div>

            {/* Recommendations List */}
            {mockRecommendations.map((rec) => (
              <div 
                key={rec.id}
                className={cn(
                  "rounded-lg border transition-all duration-200",
                  expandedRec === rec.id ? "border-violet-200 bg-violet-50/30" : "border-border bg-background",
                  selectedElementId === rec.elementId && "ring-2 ring-violet-500/50"
                )}
              >
                {/* Recommendation Header */}
                <button
                  type="button"
                  className="w-full p-3 text-left"
                  onClick={() => setExpandedRec(expandedRec === rec.id ? null : rec.id)}
                >
                  <div className="flex items-start gap-3">
                    <div className={cn(
                      "p-1.5 rounded-md",
                      rec.severity === "high" ? "bg-red-100" : 
                      rec.severity === "medium" ? "bg-amber-100" : "bg-blue-100"
                    )}>
                      {getTypeIcon(rec.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn(
                          "text-[10px] font-medium px-1.5 py-0.5 rounded border",
                          getSeverityColor(rec.severity)
                        )}>
                          {rec.severity.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-muted-foreground truncate">
                          {rec.elementName}
                        </span>
                      </div>
                      <h3 className="text-sm font-medium text-foreground">{rec.title}</h3>
                    </div>
                    <ChevronRight className={cn(
                      "size-4 text-muted-foreground transition-transform",
                      expandedRec === rec.id && "rotate-90"
                    )} />
                  </div>
                </button>

                {/* Expanded Content */}
                {expandedRec === rec.id && (
                  <div className="px-3 pb-3 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {rec.description}
                    </p>

                    {/* Metrics */}
                    <div className="flex gap-2">
                      {rec.metrics.map((metric, idx) => (
                        <div key={idx} className="flex-1 p-2 rounded-md bg-background border border-border">
                          <p className="text-[10px] text-muted-foreground mb-0.5">{metric.label}</p>
                          <div className="flex items-baseline gap-1">
                            <span className="text-sm font-semibold text-foreground">{metric.value}</span>
                            {metric.change && (
                              <span className={cn(
                                "text-[10px]",
                                metric.trend === "up" ? "text-green-600" : "text-red-600"
                              )}>
                                {metric.change}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Suggestions */}
                    <div className="space-y-2">
                      <p className="text-xs font-medium text-foreground">Suggestions:</p>
                      {rec.suggestions.map((suggestion) => (
                        <div 
                          key={suggestion.id}
                          className={cn(
                            "p-3 rounded-md border transition-all cursor-pointer",
                            selectedSuggestion === suggestion.id 
                              ? "border-violet-300 bg-violet-50" 
                              : "border-border bg-background hover:border-violet-200 hover:bg-violet-50/50",
                            appliedSuggestions.includes(suggestion.id) && "border-green-300 bg-green-50"
                          )}
                          onClick={() => setSelectedSuggestion(suggestion.id)}
                        >
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div>
                              <h4 className="text-xs font-medium text-foreground">{suggestion.title}</h4>
                              <p className="text-[10px] text-muted-foreground mt-0.5">{suggestion.description}</p>
                            </div>
                            <span className="text-[10px] font-medium text-green-600 whitespace-nowrap">
                              {suggestion.expectedImprovement}
                            </span>
                          </div>

                          {/* Preview Changes */}
                          <div className="flex flex-wrap gap-1.5 mb-2">
                            {suggestion.preview.map((change, idx) => (
                              <div key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-muted">
                                <span className="text-muted-foreground">{change.property}:</span>{" "}
                                <span className="line-through text-red-500">{change.oldValue}</span>{" "}
                                <span className="text-green-600">{change.newValue}</span>
                              </div>
                            ))}
                          </div>

                          <Button
                            size="sm"
                            className={cn(
                              "w-full h-7 text-xs",
                              appliedSuggestions.includes(suggestion.id)
                                ? "bg-green-600 hover:bg-green-700 text-white"
                                : "bg-violet-600 hover:bg-violet-700 text-white"
                            )}
                            onClick={(e) => {
                              e.stopPropagation()
                              handleApplySuggestion(rec, suggestion)
                            }}
                          >
                            {appliedSuggestions.includes(suggestion.id) ? (
                              <>
                                <Check className="size-3 mr-1" />
                                Applied
                              </>
                            ) : (
                              "Apply this suggestion"
                            )}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        <p className="text-[10px] text-muted-foreground text-center">
          Recommendations are based on aggregated user behavior data and industry benchmarks.
        </p>
      </div>
    </div>
  )
}

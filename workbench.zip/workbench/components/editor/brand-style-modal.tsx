"use client"

import React from "react"

import { useState, useRef, useEffect } from "react"
import { X, Undo2, Redo2, Save, Sun, Moon, ChevronDown, ChevronUp, Plus, Minus, ChevronLeft, ChevronRight, Send, Search, Check, Sparkles, Settings2, AlertCircle, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface BrandStyleModalProps {
  isOpen: boolean
  onClose: () => void
  onApply: (styles: BrandStyles) => void
}

interface BrandStyles {
  primary: string
  primaryForeground: string
  secondary: string
  secondaryForeground: string
  accent: string
  accentForeground: string
  background: string
  foreground: string
  muted: string
  mutedForeground: string
  card: string
  cardForeground: string
  mode: "light" | "dark"
  // Typography
  sansFont: string
  serifFont: string
  monoFont: string
  baseFontSize: number
  lineHeight: number
  bodyLetterSpacing: number
  headingLetterSpacing: number
  regularWeight: string
  boldWeight: string
}

const defaultLightStyles: BrandStyles = {
  primary: "#f59e0b",
  primaryForeground: "#000000",
  secondary: "#f3f4f6",
  secondaryForeground: "#1f2937",
  accent: "#fffbeb",
  accentForeground: "#000000",
  background: "#ffffff",
  foreground: "#262626",
  muted: "#f9fafb",
  mutedForeground: "#6b7280",
  card: "#ffffff",
  cardForeground: "#262626",
  mode: "light",
  sansFont: "Inter",
  serifFont: "Source Serif 4",
  monoFont: "JetBrains Mono",
  baseFontSize: 17,
  lineHeight: 1.5,
  bodyLetterSpacing: 0,
  headingLetterSpacing: 0,
  regularWeight: "400",
  boldWeight: "700"
}

const defaultDarkStyles: BrandStyles = {
  primary: "#f59e0b",
  primaryForeground: "#000000",
  secondary: "#27272a",
  secondaryForeground: "#fafafa",
  accent: "#f59e0b",
  accentForeground: "#000000",
  background: "#09090b",
  foreground: "#fafafa",
  muted: "#27272a",
  mutedForeground: "#a1a1aa",
  card: "#18181b",
  cardForeground: "#fafafa",
  mode: "dark",
  sansFont: "Inter",
  serifFont: "Source Serif 4",
  monoFont: "JetBrains Mono",
  baseFontSize: 17,
  lineHeight: 1.5,
  bodyLetterSpacing: 0,
  headingLetterSpacing: 0,
  regularWeight: "400",
  boldWeight: "700"
}

// Built-in themes
const builtInThemes = [
  { name: "Default", colors: ["#000000", "#6b7280", "#d1d5db", "#f3f4f6"], primary: "#000000" },
  { name: "Minimal", colors: ["#f59e0b", "#9ca3af", "#e5e7eb", "#f9fafb"], primary: "#f59e0b" },
  { name: "Amethyst Haze", colors: ["#8b5cf6", "#a78bfa", "#c4b5fd", "#ede9fe"], primary: "#8b5cf6" },
  { name: "Bold Tech", colors: ["#3b82f6", "#60a5fa", "#93c5fd", "#dbeafe"], primary: "#3b82f6" },
  { name: "Bubblegum", colors: ["#ec4899", "#f472b6", "#f9a8d4", "#fce7f3"], primary: "#ec4899" },
  { name: "Caffeine", colors: ["#78350f", "#92400e", "#d97706", "#fef3c7"], primary: "#78350f" },
  { name: "Candyland", colors: ["#f472b6", "#a855f7", "#22d3ee", "#fde047"], primary: "#f472b6" },
  { name: "Catppuccin", colors: ["#cba6f7", "#89b4fa", "#a6e3a1", "#f9e2af"], primary: "#cba6f7" },
  { name: "Claude", colors: ["#d97706", "#f59e0b", "#fbbf24", "#fef3c7"], primary: "#d97706" },
  { name: "Cosmic Night", colors: ["#6366f1", "#4f46e5", "#818cf8", "#1e1b4b"], primary: "#6366f1" },
  { name: "Cyberpunk", colors: ["#f472b6", "#a855f7", "#22d3ee", "#fde047"], primary: "#f472b6" },
  { name: "Elegant Luxury", colors: ["#d97706", "#a16207", "#f3f4f6", "#fafaf9"], primary: "#d97706" },
  { name: "Kodama Grove", colors: ["#22c55e", "#4ade80", "#86efac", "#dcfce7"], primary: "#22c55e" },
  { name: "Modern Minimal", colors: ["#18181b", "#71717a", "#d4d4d8", "#fafafa"], primary: "#18181b" },
]

interface ColorPickerRowProps {
  label: string
  hex: string
  onChange: (hex: string) => void
}

function ColorPickerRow({ label, hex, onChange }: ColorPickerRowProps) {
  return (
    <div className="flex items-center justify-between py-3 px-4 border border-gray-200 rounded-lg">
      <div>
        <p className="text-sm font-medium text-gray-900">{label}</p>
        <p className="text-xs text-gray-500">{hex}</p>
      </div>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={hex}
          onChange={(e) => onChange(e.target.value)}
          className="w-8 h-8 rounded-full cursor-pointer border-0 p-0 overflow-hidden"
          style={{ WebkitAppearance: "none" }}
        />
        <button className="w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center">
          <div className="w-3 h-3 border-2 border-white rounded-sm" />
        </button>
      </div>
    </div>
  )
}

interface CollapsibleSectionProps {
  title: string
  isOpen: boolean
  onToggle: () => void
  children: React.ReactNode
}

function CollapsibleSection({ title, isOpen, onToggle, children }: CollapsibleSectionProps) {
  return (
    <div className="border-b border-gray-100">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-3 px-1 text-sm font-medium text-gray-900 hover:bg-gray-50"
      >
        {title}
        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {isOpen && <div className="pb-4 space-y-2">{children}</div>}
    </div>
  )
}

export function BrandStyleModal({ isOpen, onClose, onApply }: BrandStyleModalProps) {
  const [styles, setStyles] = useState<BrandStyles>(defaultLightStyles)
  const [activeTab, setActiveTab] = useState<"colors" | "type" | "effects">("colors")
  const [previewTab, setPreviewTab] = useState("cards")
  const [showThemeDropdown, setShowThemeDropdown] = useState(false)
  const [themeSearch, setThemeSearch] = useState("")
  const [selectedTheme, setSelectedTheme] = useState("Minimal")
  const dropdownRef = useRef<HTMLDivElement>(null)
  const [expandedSections, setExpandedSections] = useState({
    primary: true,
    secondary: false,
    accent: false,
    base: true,
    card: false,
    sidebar: false,
    utility: false
  })

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowThemeDropdown(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const filteredThemes = builtInThemes.filter(theme => 
    theme.name.toLowerCase().includes(themeSearch.toLowerCase())
  )

  const selectTheme = (theme: typeof builtInThemes[0]) => {
    setSelectedTheme(theme.name)
    updateStyle("primary", theme.primary)
    setShowThemeDropdown(false)
  }

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }))
  }

  const updateStyle = (key: keyof BrandStyles, value: string) => {
    setStyles(prev => ({ ...prev, [key]: value }))
  }

  const toggleMode = (mode: "light" | "dark") => {
    if (mode === "dark") {
      setStyles(prev => ({ ...defaultDarkStyles, primary: prev.primary, accent: prev.primary }))
    } else {
      setStyles(prev => ({ ...defaultLightStyles, primary: prev.primary, accent: prev.primary }))
    }
  }

  const handleApply = () => {
    onApply(styles)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div 
        className="bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1400px] h-[90vh] max-h-[800px] flex flex-col overflow-hidden"
        style={{ backgroundColor: styles.mode === "dark" ? "#09090b" : "#ffffff" }}
      >
        {/* Header */}
        <div 
          className="flex items-center justify-between px-6 py-4 border-b"
          style={{ 
            borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
            color: styles.mode === "dark" ? "#fafafa" : "#111827"
          }}
        >
          <h2 className="text-lg font-semibold">Brand Style</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-md">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div 
          className="flex items-center justify-between px-6 py-3 border-b"
          style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
        >
          <div className="flex items-center gap-4">
            <div className="relative" ref={dropdownRef}>
              <button 
                onClick={() => setShowThemeDropdown(!showThemeDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 border rounded-lg text-sm font-medium hover:bg-gray-50"
                style={{ 
                  borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                  color: styles.mode === "dark" ? "#fafafa" : "#111827"
                }}
              >
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: styles.primary }} />
                {selectedTheme}
                <ChevronDown className="w-3 h-3" />
              </button>

              {/* Theme Dropdown */}
              {showThemeDropdown && (
                <div 
                  className="absolute top-full left-0 mt-2 w-72 bg-white rounded-xl shadow-xl border z-50 overflow-hidden"
                  style={{ borderColor: "#e5e7eb" }}
                >
                  {/* Search */}
                  <div className="p-3 border-b" style={{ borderColor: "#e5e7eb" }}>
                    <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg">
                      <Search className="w-4 h-4 text-gray-400" />
                      <input 
                        type="text"
                        placeholder="Search themes..."
                        value={themeSearch}
                        onChange={(e) => setThemeSearch(e.target.value)}
                        className="flex-1 bg-transparent text-sm outline-none"
                      />
                    </div>
                  </div>

                  {/* Theme count */}
                  <div className="px-4 py-2 flex items-center justify-between text-xs text-gray-500 border-b" style={{ borderColor: "#e5e7eb" }}>
                    <span>{filteredThemes.length} themes available</span>
                    <Settings2 className="w-4 h-4" />
                  </div>

                  {/* Theme list */}
                  <div className="max-h-[300px] overflow-y-auto">
                    <div className="px-4 py-2 text-xs font-medium text-gray-500">Built-in Themes</div>
                    {filteredThemes.map((theme) => (
                      <button
                        key={theme.name}
                        onClick={() => selectTheme(theme)}
                        className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-gray-50"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex -space-x-1">
                            {theme.colors.map((color, i) => (
                              <div 
                                key={i}
                                className="w-4 h-4 rounded-full border border-white"
                                style={{ backgroundColor: color }}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-900">{theme.name}</span>
                        </div>
                        {selectedTheme === theme.name && (
                          <Check className="w-4 h-4 text-gray-600" />
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Add new style button */}
                  <div className="p-3 border-t" style={{ borderColor: "#e5e7eb" }}>
                    <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-900 text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors">
                      <Sparkles className="w-4 h-4" />
                      Add your new style or design system here
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button className="p-2 hover:bg-gray-100 rounded-md">
                <Undo2 className="w-4 h-4 text-gray-500" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-md">
                <Redo2 className="w-4 h-4 text-gray-500" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-md">
                <Save className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500 mr-2">Preview Demos</span>
            {["Cards", "Dashboard", "Mail", "Pricing", "Colors", "Type"].map((tab) => (
              <button
                key={tab}
                onClick={() => setPreviewTab(tab.toLowerCase())}
                className={cn(
                  "px-3 py-1.5 text-sm rounded-md",
                  previewTab === tab.toLowerCase() 
                    ? "bg-gray-100 text-gray-900" 
                    : "text-gray-500 hover:text-gray-700"
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-gray-400" />
            <button
              onClick={() => toggleMode(styles.mode === "light" ? "dark" : "light")}
              className={cn(
                "w-12 h-6 rounded-full p-1 transition-colors",
                styles.mode === "dark" ? "bg-gray-700" : "bg-gray-200"
              )}
            >
              <div 
                className={cn(
                  "w-4 h-4 rounded-full bg-white transition-transform",
                  styles.mode === "dark" ? "translate-x-6" : "translate-x-0"
                )}
              />
            </button>
            <Moon className="w-4 h-4 text-gray-400" />
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Left Sidebar */}
          <div 
            className="w-72 border-r overflow-y-auto p-4"
            style={{ 
              borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
              backgroundColor: styles.mode === "dark" ? "#09090b" : "#ffffff"
            }}
          >
            {/* Tabs */}
            <div className="flex gap-1 p-1 bg-gray-100 rounded-lg mb-4">
              {(["colors", "type", "effects"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    "flex-1 py-2 text-sm font-medium rounded-md capitalize",
                    activeTab === tab ? "bg-white shadow-sm" : "text-gray-500"
                  )}
                >
                  {tab === "colors" ? "Colors" : tab === "type" ? "Type" : "Effects"}
                </button>
              ))}
            </div>

            {/* Light/Dark Toggle */}
            <div className="flex gap-2 mb-6">
              <button
                onClick={() => toggleMode("light")}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-md border",
                  styles.mode === "light" ? "border-gray-300 bg-white" : "border-transparent text-gray-500"
                )}
              >
                <Sun className="w-4 h-4" />
                Light
              </button>
              <button
                onClick={() => toggleMode("dark")}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-md border",
                  styles.mode === "dark" ? "border-gray-300 bg-gray-800 text-white" : "border-transparent text-gray-500"
                )}
              >
                <Moon className="w-4 h-4" />
                Dark
              </button>
            </div>

            {/* Color Sections */}
            {activeTab === "colors" && (
              <div className="space-y-1">
                <CollapsibleSection 
                  title="Primary Colors" 
                  isOpen={expandedSections.primary}
                  onToggle={() => toggleSection("primary")}
                >
                  <ColorPickerRow 
                    label="Primary" 
                    hex={styles.primary} 
                    onChange={(v) => updateStyle("primary", v)} 
                  />
                  <ColorPickerRow 
                    label="Primary Foreground" 
                    hex={styles.primaryForeground} 
                    onChange={(v) => updateStyle("primaryForeground", v)} 
                  />
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Secondary Colors" 
                  isOpen={expandedSections.secondary}
                  onToggle={() => toggleSection("secondary")}
                >
                  <ColorPickerRow 
                    label="Secondary" 
                    hex={styles.secondary} 
                    onChange={(v) => updateStyle("secondary", v)} 
                  />
                  <ColorPickerRow 
                    label="Secondary Foreground" 
                    hex={styles.secondaryForeground} 
                    onChange={(v) => updateStyle("secondaryForeground", v)} 
                  />
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Accent Colors" 
                  isOpen={expandedSections.accent}
                  onToggle={() => toggleSection("accent")}
                >
                  <ColorPickerRow 
                    label="Accent" 
                    hex={styles.accent} 
                    onChange={(v) => updateStyle("accent", v)} 
                  />
                  <ColorPickerRow 
                    label="Accent Foreground" 
                    hex={styles.accentForeground} 
                    onChange={(v) => updateStyle("accentForeground", v)} 
                  />
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Base Colors" 
                  isOpen={expandedSections.base}
                  onToggle={() => toggleSection("base")}
                >
                  <ColorPickerRow 
                    label="Background" 
                    hex={styles.background} 
                    onChange={(v) => updateStyle("background", v)} 
                  />
                  <ColorPickerRow 
                    label="Foreground" 
                    hex={styles.foreground} 
                    onChange={(v) => updateStyle("foreground", v)} 
                  />
                  <ColorPickerRow 
                    label="Muted" 
                    hex={styles.muted} 
                    onChange={(v) => updateStyle("muted", v)} 
                  />
                  <ColorPickerRow 
                    label="Muted Foreground" 
                    hex={styles.mutedForeground} 
                    onChange={(v) => updateStyle("mutedForeground", v)} 
                  />
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Card & Popover" 
                  isOpen={expandedSections.card}
                  onToggle={() => toggleSection("card")}
                >
                  <ColorPickerRow 
                    label="Card" 
                    hex={styles.card} 
                    onChange={(v) => updateStyle("card", v)} 
                  />
                  <ColorPickerRow 
                    label="Card Foreground" 
                    hex={styles.cardForeground} 
                    onChange={(v) => updateStyle("cardForeground", v)} 
                  />
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Sidebar Colors" 
                  isOpen={expandedSections.sidebar}
                  onToggle={() => toggleSection("sidebar")}
                >
                  <p className="text-sm text-gray-500 px-1">Sidebar color options</p>
                </CollapsibleSection>

                <CollapsibleSection 
                  title="Utility Colors" 
                  isOpen={expandedSections.utility}
                  onToggle={() => toggleSection("utility")}
                >
                  <p className="text-sm text-gray-500 px-1">Utility color options</p>
                </CollapsibleSection>
              </div>
            )}

            {activeTab === "type" && (
              <div className="space-y-1">
                {/* Font Family */}
                <CollapsibleSection 
                  title="Font Family" 
                  isOpen={expandedSections.primary}
                  onToggle={() => toggleSection("primary")}
                >
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block">Sans-Serif Font</label>
                      <select 
                        value={styles.sansFont}
                        onChange={(e) => updateStyle("sansFont", e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg text-sm bg-white"
                        style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                      >
                        <option value="Inter">Inter</option>
                        <option value="Roboto">Roboto</option>
                        <option value="Open Sans">Open Sans</option>
                        <option value="Poppins">Poppins</option>
                        <option value="Nunito">Nunito</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block">Serif Font</label>
                      <select 
                        value={styles.serifFont}
                        onChange={(e) => updateStyle("serifFont", e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg text-sm bg-white"
                        style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                      >
                        <option value="Source Serif 4">Source Serif 4</option>
                        <option value="Merriweather">Merriweather</option>
                        <option value="Playfair Display">Playfair Display</option>
                        <option value="Lora">Lora</option>
                        <option value="PT Serif">PT Serif</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block">Monospace Font</label>
                      <select 
                        value={styles.monoFont}
                        onChange={(e) => updateStyle("monoFont", e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg text-sm bg-white"
                        style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                      >
                        <option value="JetBrains Mono">JetBrains Mono</option>
                        <option value="Fira Code">Fira Code</option>
                        <option value="Source Code Pro">Source Code Pro</option>
                        <option value="IBM Plex Mono">IBM Plex Mono</option>
                        <option value="Roboto Mono">Roboto Mono</option>
                      </select>
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Font Sizing */}
                <CollapsibleSection 
                  title="Font Sizing" 
                  isOpen={expandedSections.secondary}
                  onToggle={() => toggleSection("secondary")}
                >
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-500">Base Font Size</label>
                        <div className="flex items-center gap-1">
                          <input 
                            type="number"
                            value={styles.baseFontSize}
                            onChange={(e) => updateStyle("baseFontSize", e.target.value)}
                            className="w-12 px-2 py-1 text-xs border rounded text-center"
                            style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                          />
                          <span className="text-xs text-gray-400">px</span>
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="12"
                        max="24"
                        value={styles.baseFontSize}
                        onChange={(e) => updateStyle("baseFontSize", e.target.value)}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-500">Line Height</label>
                        <div className="flex items-center gap-1">
                          <input 
                            type="number"
                            step="0.1"
                            value={styles.lineHeight}
                            onChange={(e) => updateStyle("lineHeight", e.target.value)}
                            className="w-12 px-2 py-1 text-xs border rounded text-center"
                            style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                          />
                          <span className="text-xs text-gray-400">em</span>
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="1"
                        max="2.5"
                        step="0.1"
                        value={styles.lineHeight}
                        onChange={(e) => updateStyle("lineHeight", e.target.value)}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Letter Spacing */}
                <CollapsibleSection 
                  title="Letter Spacing" 
                  isOpen={expandedSections.accent}
                  onToggle={() => toggleSection("accent")}
                >
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-500">Body Text</label>
                        <div className="flex items-center gap-1">
                          <input 
                            type="number"
                            step="0.01"
                            value={styles.bodyLetterSpacing}
                            onChange={(e) => updateStyle("bodyLetterSpacing", e.target.value)}
                            className="w-12 px-2 py-1 text-xs border rounded text-center"
                            style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                          />
                          <span className="text-xs text-gray-400">em</span>
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="-0.1"
                        max="0.2"
                        step="0.01"
                        value={styles.bodyLetterSpacing}
                        onChange={(e) => updateStyle("bodyLetterSpacing", e.target.value)}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-500">Headings</label>
                        <div className="flex items-center gap-1">
                          <input 
                            type="number"
                            step="0.01"
                            value={styles.headingLetterSpacing}
                            onChange={(e) => updateStyle("headingLetterSpacing", e.target.value)}
                            className="w-12 px-2 py-1 text-xs border rounded text-center"
                            style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                          />
                          <span className="text-xs text-gray-400">em</span>
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="-0.1"
                        max="0.2"
                        step="0.01"
                        value={styles.headingLetterSpacing}
                        onChange={(e) => updateStyle("headingLetterSpacing", e.target.value)}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Font Weights */}
                <CollapsibleSection 
                  title="Font Weights" 
                  isOpen={expandedSections.base}
                  onToggle={() => toggleSection("base")}
                >
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block">Regular Weight</label>
                      <select 
                        value={styles.regularWeight}
                        onChange={(e) => updateStyle("regularWeight", e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg text-sm bg-white"
                        style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                      >
                        <option value="300">Light (300)</option>
                        <option value="400">Regular (400)</option>
                        <option value="500">Medium (500)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block">Bold Weight</label>
                      <select 
                        value={styles.boldWeight}
                        onChange={(e) => updateStyle("boldWeight", e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg text-sm bg-white"
                        style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                      >
                        <option value="600">Semi-Bold (600)</option>
                        <option value="700">Bold (700)</option>
                        <option value="800">Extra-Bold (800)</option>
                      </select>
                    </div>
                  </div>
                </CollapsibleSection>
              </div>
            )}

            {activeTab === "effects" && (
              <div className="space-y-4">
                <p className="text-sm text-gray-500">Effects settings coming soon</p>
              </div>
            )}
          </div>

          {/* Preview Area */}
          <div 
            className="flex-1 p-6 overflow-y-auto"
            style={{ backgroundColor: styles.mode === "dark" ? "#18181b" : "#f9fafb" }}
          >
            {/* Color Palette Preview */}
            {previewTab === "colors" && (
              <div 
                className="max-w-4xl mx-auto"
                style={{ 
                  fontFamily: styles.sansFont,
                  fontSize: `${styles.baseFontSize}px`,
                  lineHeight: styles.lineHeight,
                  letterSpacing: `${styles.bodyLetterSpacing}em`
                }}
              >
                <h1 className="text-4xl mb-3" style={{ color: styles.foreground, fontWeight: styles.boldWeight, letterSpacing: `${styles.headingLetterSpacing}em` }}>Color Palette</h1>
                <p className="text-lg mb-8" style={{ color: styles.mutedForeground }}>
                  The semantic color system defines the visual tone and hierarchy of your application.
                </p>

                {/* Brand Identity */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-5 rounded-full" style={{ backgroundColor: styles.primary }} />
                      <h2 className="text-lg font-semibold" style={{ color: styles.foreground }}>Brand Identity</h2>
                    </div>
                    <span className="text-sm font-medium" style={{ color: styles.primary }}>CORE COLORS</span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between" style={{ backgroundColor: styles.primary }}>
                      <span className="font-semibold" style={{ color: styles.primaryForeground }}>Primary</span>
                      <div>
                        <p className="text-xs font-mono opacity-70" style={{ color: styles.primaryForeground }}>--primary</p>
                        <p className="text-sm font-mono" style={{ color: styles.primaryForeground }}>{styles.primary.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between border" style={{ backgroundColor: styles.secondary, borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                      <span className="font-semibold" style={{ color: styles.secondaryForeground }}>Secondary</span>
                      <div>
                        <p className="text-xs font-mono opacity-70" style={{ color: styles.mutedForeground }}>--secondary</p>
                        <p className="text-sm font-mono" style={{ color: styles.secondaryForeground }}>{styles.secondary.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between" style={{ backgroundColor: styles.accent }}>
                      <span className="font-semibold" style={{ color: styles.primary }}>Accent</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.primary }}>--accent</p>
                        <p className="text-sm font-mono" style={{ color: styles.primary }}>{styles.accent.toUpperCase()}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Surfaces & Backgrounds */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-5 rounded-full bg-gray-400" />
                      <h2 className="text-lg font-semibold" style={{ color: styles.foreground }}>Surfaces & Backgrounds</h2>
                    </div>
                    <span className="text-sm font-medium text-gray-400">STRUCTURE</span>
                  </div>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="rounded-xl p-5 h-28 flex flex-col justify-between border" style={{ backgroundColor: styles.background, borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                      <span className="font-semibold" style={{ color: styles.foreground }}>Background</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--background</p>
                        <p className="text-sm font-mono" style={{ color: styles.foreground }}>{styles.background.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-28 flex flex-col justify-between border" style={{ backgroundColor: styles.card, borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                      <span className="font-semibold" style={{ color: styles.cardForeground }}>Card</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--card</p>
                        <p className="text-sm font-mono" style={{ color: styles.cardForeground }}>{styles.card.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-28 flex flex-col justify-between border" style={{ backgroundColor: styles.card, borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                      <span className="font-semibold" style={{ color: styles.cardForeground }}>Popover</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--popover</p>
                        <p className="text-sm font-mono" style={{ color: styles.cardForeground }}>{styles.card.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-28 flex flex-col justify-between border" style={{ backgroundColor: styles.muted, borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                      <span className="font-semibold" style={{ color: styles.mutedForeground }}>Muted</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--muted</p>
                        <p className="text-sm font-mono" style={{ color: styles.mutedForeground }}>{styles.muted.toUpperCase()}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Functional & Status */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-5 rounded-full bg-red-500" />
                      <h2 className="text-lg font-semibold" style={{ color: styles.foreground }}>Functional & Status</h2>
                    </div>
                    <span className="text-sm font-medium text-gray-400">UTILITY</span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between bg-red-500">
                      <span className="font-semibold text-white">Destructive</span>
                      <div>
                        <p className="text-xs font-mono text-red-200">--destructive</p>
                        <p className="text-sm font-mono text-white">#EF4444</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                      <span className="font-semibold" style={{ color: styles.foreground }}>Border</span>
                      <div>
                        <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>#e5e7eb</p>
                      </div>
                    </div>
                    <div className="rounded-xl p-5 h-32 flex flex-col justify-between border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                      <span className="font-semibold" style={{ color: styles.foreground }}>Input</span>
                      <div className="border rounded-md px-3 py-1.5 text-sm mt-2" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }} />
                      <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>#e5e7eb</p>
                    </div>
                  </div>
                </div>

                {/* Ring & Focus States */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-5 rounded-full" style={{ backgroundColor: styles.primary }} />
                      <h2 className="text-lg font-semibold" style={{ color: styles.foreground }}>Ring & Focus States</h2>
                    </div>
                    <span className="text-sm font-medium text-gray-400">ACCESSIBILITY</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {/* Ring Color */}
                    <div className="rounded-xl p-5 border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="font-medium" style={{ color: styles.foreground }}>Ring Color</p>
                          <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--ring</p>
                        </div>
                        <div className="w-6 h-6 rounded-full" style={{ backgroundColor: styles.primary }} />
                      </div>
                      <div className="flex items-center gap-2 mb-3">
                        <button 
                          className="px-4 py-2 rounded-md text-sm font-medium ring-2 ring-offset-2"
                          style={{ 
                            backgroundColor: styles.primary, 
                            color: styles.primaryForeground,
                            ringColor: styles.primary
                          }}
                        >
                          Focused Button
                        </button>
                        <input 
                          type="text"
                          placeholder="Click to focus"
                          className="px-3 py-2 text-sm border rounded-md"
                          style={{ borderColor: "#e5e7eb" }}
                        />
                      </div>
                      <p className="text-xs" style={{ color: styles.mutedForeground }}>
                        Ring colors indicate focus states for interactive elements, essential for keyboard navigation and accessibility.
                      </p>
                    </div>

                    {/* Sidebar Ring */}
                    <div className="rounded-xl p-5 border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="font-medium" style={{ color: styles.foreground }}>Sidebar Ring</p>
                          <p className="text-xs font-mono" style={{ color: styles.mutedForeground }}>--sidebar-ring</p>
                        </div>
                        <div className="w-6 h-6 rounded-full" style={{ backgroundColor: styles.primary }} />
                      </div>
                      <div className="space-y-2 mb-3">
                        <div 
                          className="flex items-center gap-2 px-3 py-2 rounded-md text-sm"
                          style={{ backgroundColor: `${styles.primary}20`, color: styles.primary }}
                        >
                          <Home className="w-4 h-4" />
                          Focused Nav Item
                        </div>
                        <div className="flex items-center gap-2 px-3 py-2 text-sm" style={{ color: styles.mutedForeground }}>
                          <Settings2 className="w-4 h-4" />
                          Normal Nav Item
                        </div>
                      </div>
                      <p className="text-xs" style={{ color: styles.mutedForeground }}>
                        Sidebar ring provides focus indication within sidebar navigation contexts.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Simple Demo */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-5 rounded-full" style={{ backgroundColor: styles.primary }} />
                      <h2 className="text-lg font-semibold" style={{ color: styles.foreground }}>Simple Demo</h2>
                    </div>
                    <span className="text-sm font-medium text-gray-400">PREVIEW</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {/* Project Settings Card */}
                    <div className="rounded-xl border overflow-hidden" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                      <div className="h-1" style={{ backgroundColor: styles.primary }} />
                      <div className="p-5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium" style={{ color: styles.primary }}>New Feature</span>
                          <span className="text-xs" style={{ color: styles.mutedForeground }}>Just now</span>
                        </div>
                        <h3 className="text-lg font-semibold mb-1" style={{ color: styles.foreground }}>Project Settings</h3>
                        <p className="text-sm mb-4" style={{ color: styles.mutedForeground }}>Manage your project configuration and deployment preferences.</p>
                        
                        <div className="mb-4">
                          <label className="text-sm font-medium mb-1.5 block" style={{ color: styles.foreground }}>Project Name</label>
                          <input 
                            type="text"
                            defaultValue="SuperDesign Platform"
                            className="w-full px-3 py-2 text-sm border rounded-md"
                            style={{ borderColor: "#e5e7eb", backgroundColor: styles.mode === "dark" ? "#27272a" : "#ffffff" }}
                          />
                        </div>
                        
                        <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-md" style={{ backgroundColor: `${styles.primary}15` }}>
                          <AlertCircle className="w-4 h-4" style={{ color: styles.primary }} />
                          <span className="text-xs" style={{ color: styles.primary }}>Changes will be reflected immediately.</span>
                        </div>

                        <div className="flex items-center justify-between">
                          <button className="text-sm" style={{ color: styles.mutedForeground }}>Cancel</button>
                          <button 
                            className="px-4 py-2 rounded-md text-sm font-medium"
                            style={{ backgroundColor: styles.primary, color: styles.primaryForeground }}
                          >
                            Save Changes
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Buttons, Badges, Alerts */}
                    <div className="space-y-4">
                      {/* Buttons */}
                      <div className="rounded-xl p-5 border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                        <p className="text-xs font-medium mb-3" style={{ color: styles.mutedForeground }}>BUTTONS</p>
                        <div className="flex flex-wrap gap-2 mb-2">
                          <button className="px-4 py-2 rounded-md text-sm font-medium" style={{ backgroundColor: styles.primary, color: styles.primaryForeground }}>Primary</button>
                          <button className="px-4 py-2 rounded-md text-sm font-medium" style={{ backgroundColor: styles.secondary, color: styles.secondaryForeground }}>Secondary</button>
                          <button className="px-4 py-2 rounded-md text-sm font-medium border" style={{ borderColor: "#e5e7eb", color: styles.foreground }}>Outline</button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <button className="px-4 py-2 rounded-md text-sm font-medium bg-red-500 text-white">Destructive</button>
                          <button className="px-4 py-2 rounded-md text-sm font-medium" style={{ color: styles.mutedForeground }}>Ghost</button>
                        </div>
                      </div>

                      {/* Badges */}
                      <div className="rounded-xl p-5 border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                        <p className="text-xs font-medium mb-3" style={{ color: styles.mutedForeground }}>BADGES</p>
                        <div className="flex flex-wrap gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: styles.primary, color: styles.primaryForeground }}>Default</span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: styles.secondary, color: styles.secondaryForeground }}>Secondary</span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium border" style={{ borderColor: "#e5e7eb", color: styles.foreground }}>Outline</span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-500 text-white">Destructive</span>
                        </div>
                      </div>

                      {/* Alert States */}
                      <div className="rounded-xl p-5 border" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb", backgroundColor: styles.card }}>
                        <p className="text-xs font-medium mb-3" style={{ color: styles.mutedForeground }}>ALERT STATES</p>
                        <div className="flex items-start gap-3 px-4 py-3 rounded-md bg-red-50 border border-red-200">
                          <AlertCircle className="w-4 h-4 text-red-500 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-red-700">Critical Error</p>
                            <p className="text-xs text-red-600">Something went wrong with your request.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Cards Preview */}
            {previewTab === "cards" && (
              <div 
                className="grid grid-cols-3 gap-4 max-w-5xl mx-auto"
                style={{ 
                  fontFamily: styles.sansFont,
                  fontSize: `${styles.baseFontSize}px`,
                  lineHeight: styles.lineHeight,
                  letterSpacing: `${styles.bodyLetterSpacing}em`
                }}
              >
                {/* Total Revenue Card */}
                <div 
                  className="col-span-2 rounded-xl p-6 shadow-sm border"
                  style={{ 
                    backgroundColor: styles.card,
                    borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                    color: styles.cardForeground,
                    fontWeight: styles.regularWeight
                  }}
                >
                  <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-3xl" style={{ fontWeight: styles.boldWeight, letterSpacing: `${styles.headingLetterSpacing}em` }}>$45,231.89</span>
                    <span className="text-sm" style={{ color: styles.primary }}>+20.1%</span>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">Revenue, profit, and growth trends</p>
                  
                  {/* Chart placeholder */}
                  <div className="h-40 flex items-end gap-2">
                    {[40, 55, 45, 60, 75, 65].map((h, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1">
                        <div 
                          className="w-full rounded-t-md transition-all"
                          style={{ 
                            height: `${h}%`,
                            backgroundColor: styles.primary,
                            opacity: 0.8
                          }}
                        />
                        <span className="text-xs text-gray-400">
                          {["Jan", "Feb", "Mar", "Apr", "May", "Jun"][i]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Subscriptions Card */}
                <div 
                  className="rounded-xl p-6 shadow-sm border"
                  style={{ 
                    backgroundColor: styles.card,
                    borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                    color: styles.cardForeground
                  }}
                >
                  <p className="text-sm text-gray-500 mb-1">Subscriptions</p>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-2xl" style={{ fontWeight: styles.boldWeight, letterSpacing: `${styles.headingLetterSpacing}em` }}>+2,350</span>
                    <span className="text-sm" style={{ color: styles.primary }}>+180.1%</span>
                  </div>
                  <p className="text-xs text-gray-500 mb-4">Active, new, and churned subscribers</p>
                  
                  {/* Line chart placeholder */}
                  <div className="h-24 relative">
                    <svg className="w-full h-full" viewBox="0 0 200 80">
                      <path 
                        d="M0 60 Q50 50 100 40 T200 20" 
                        fill="none" 
                        stroke={styles.primary}
                        strokeWidth="2"
                        opacity="0.8"
                      />
                      <path 
                        d="M0 70 Q50 65 100 55 T200 50" 
                        fill="none" 
                        stroke="#ef4444"
                        strokeWidth="2"
                        opacity="0.6"
                      />
                      <path 
                        d="M0 75 Q50 70 100 65 T200 60" 
                        fill="none" 
                        stroke="#22c55e"
                        strokeWidth="2"
                        opacity="0.6"
                      />
                    </svg>
                  </div>
                  <div className="flex gap-4 text-xs mt-2">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: styles.primary }} />
                      Active
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-red-500" />
                      Churned
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-green-500" />
                      New
                    </span>
                  </div>
                </div>

                {/* Calendar Card */}
                <div 
                  className="rounded-xl p-6 shadow-sm border"
                  style={{ 
                    backgroundColor: styles.card,
                    borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                    color: styles.cardForeground
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-medium">October 2024</span>
                    <div className="flex gap-1">
                      <button className="p-1 hover:bg-gray-100 rounded">
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button className="p-1 hover:bg-gray-100 rounded">
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center text-xs mb-2">
                    {["SU", "MO", "TU", "WE", "TH", "FR", "SA"].map(d => (
                      <span key={d} className="text-gray-400 py-1">{d}</span>
                    ))}
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center text-sm">
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                      <button
                        key={day}
                        className={cn(
                          "py-1.5 rounded-md",
                          day === 14 
                            ? "text-white" 
                            : "hover:bg-gray-100"
                        )}
                        style={day === 14 ? { backgroundColor: styles.primary } : {}}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                  <div className="mt-4 pt-4 border-t" style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: styles.primary }} />
                      <div>
                        <p className="text-sm font-medium">Team Meeting</p>
                        <p className="text-xs text-gray-500">10:00 AM - 11:00 AM</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Move Goal Card */}
                <div 
                  className="rounded-xl p-6 shadow-sm border"
                  style={{ 
                    backgroundColor: styles.card,
                    borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                    color: styles.cardForeground
                  }}
                >
                  <h3 className="text-lg mb-1" style={{ fontWeight: styles.boldWeight, letterSpacing: `${styles.headingLetterSpacing}em` }}>Move Goal</h3>
                  <p className="text-sm text-gray-500 mb-4">Set your daily activity goal.</p>
                  
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <button className="w-10 h-10 rounded-full border flex items-center justify-center hover:bg-gray-50"
                      style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="text-center">
                      <span className="text-4xl" style={{ fontWeight: styles.boldWeight }}>350</span>
                      <p className="text-xs text-gray-500">CALORIES/DAY</p>
                    </div>
                    <button className="w-10 h-10 rounded-full border flex items-center justify-center hover:bg-gray-50"
                      style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Mini chart */}
                  <div className="h-16 flex items-end gap-1 mb-4">
                    {[30, 45, 35, 60, 50, 70, 55].map((h, i) => (
                      <div 
                        key={i} 
                        className="flex-1 rounded-t"
                        style={{ 
                          height: `${h}%`,
                          backgroundColor: styles.primary,
                          opacity: 0.7
                        }}
                      />
                    ))}
                  </div>

                  <button 
                    className="w-full py-2.5 rounded-lg text-sm font-medium"
                    style={{ 
                      backgroundColor: styles.primary,
                      color: styles.primaryForeground
                    }}
                  >
                    Set Goal
                  </button>
                </div>

                {/* Chat Card */}
                <div 
                  className="rounded-xl p-6 shadow-sm border"
                  style={{ 
                    backgroundColor: styles.card,
                    borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                    color: styles.cardForeground
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-400" />
                      <div>
                        <p className="text-sm" style={{ fontWeight: styles.boldWeight }}>Sofia Davis</p>
                        <p className="text-xs text-gray-500">m@example.com</p>
                      </div>
                    </div>
                    <button className="p-1">
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="bg-gray-100 rounded-lg p-3 text-sm" style={{ backgroundColor: styles.muted }}>
                      Hi, how can I help you today?
                    </div>
                    <div 
                      className="rounded-lg p-3 text-sm ml-8"
                      style={{ 
                        backgroundColor: styles.primary,
                        color: styles.primaryForeground
                      }}
                    >
                      Hey, I'm having trouble with my account.
                    </div>
                    <div className="bg-gray-100 rounded-lg p-3 text-sm" style={{ backgroundColor: styles.muted }}>
                      What seems to be the problem?
                    </div>
                    <div 
                      className="rounded-lg p-3 text-sm ml-8 border"
                      style={{ borderColor: styles.primary, color: styles.primary }}
                    >
                      I can't log in.
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input 
                      type="text" 
                      placeholder="Type your message..."
                      className="flex-1 px-3 py-2 text-sm border rounded-lg"
                      style={{ 
                        borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb",
                        backgroundColor: styles.mode === "dark" ? "#27272a" : "#ffffff"
                      }}
                    />
                    <button 
                      className="p-2 rounded-lg"
                      style={{ backgroundColor: styles.primary, color: styles.primaryForeground }}
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div 
          className="flex items-center justify-end gap-3 px-6 py-4 border-t"
          style={{ borderColor: styles.mode === "dark" ? "#27272a" : "#e5e7eb" }}
        >
          <Button variant="outline" onClick={onClose} className="bg-transparent">
            Cancel
          </Button>
          <Button 
            onClick={handleApply}
            style={{ backgroundColor: styles.primary, color: styles.primaryForeground }}
          >
            Apply Brand Style
          </Button>
        </div>
      </div>
    </div>
  )
}

export type { BrandStyles }

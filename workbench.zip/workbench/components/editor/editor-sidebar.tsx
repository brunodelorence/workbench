"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { PropertiesSidebar, ElementStyles } from "./properties-sidebar"
import { ChatSidebar, TemplateType } from "./chat-sidebar"
import { type BrandStyles } from "./brand-style-modal"

export type { TemplateType } from "./chat-sidebar"
export type { BrandStyles } from "./brand-style-modal"

export interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  colors?: string[]
  createdUI?: string
  issues?: string
}

interface EditorSidebarProps {
  selectedElementId: string | null
  selectedElementType: string
  styles: ElementStyles
  onStyleChange: (styles: Partial<ElementStyles>) => void
  chatMessages: ChatMessage[]
  onSendChatMessage: (message: string) => void
  isChatProcessing?: boolean
  redesignUrl?: string
  initialTab?: "properties" | "chat"
  onOpenBrand?: () => void
  onTemplateChange?: (template: TemplateType) => void
  currentTemplate?: TemplateType
  onApplyBrandStyles?: (styles: BrandStyles) => void
  hasBrandStyle?: boolean
}

export function EditorSidebar({
  selectedElementId,
  selectedElementType,
  styles,
  onStyleChange,
  chatMessages,
  onSendChatMessage,
  isChatProcessing = false,
  redesignUrl,
  initialTab = "properties",
  onOpenBrand,
  onTemplateChange,
  currentTemplate = "marketing",
  onApplyBrandStyles,
  hasBrandStyle = false
}: EditorSidebarProps) {
  const [activeTab, setActiveTab] = useState<string>(initialTab)

  return (
    <div className="w-[380px] border-r border-gray-200 bg-white flex flex-col h-full">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
        {/* Tab Headers */}
        <div className="border-b border-gray-200 px-2 pt-2">
          <TabsList className="w-full bg-gray-100/50 p-1 rounded-lg grid grid-cols-2 h-10">
            <TabsTrigger 
              value="properties" 
              className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md text-sm"
            >
              Properties
            </TabsTrigger>
            <TabsTrigger 
              value="chat" 
              className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md text-sm relative"
            >
              Chat
              {chatMessages.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 text-white text-[10px] rounded-full flex items-center justify-center">
                  {chatMessages.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Tab Contents */}
        <TabsContent value="properties" className="flex-1 m-0 overflow-hidden">
          <PropertiesSidebar
            selectedElementId={selectedElementId}
            selectedElementType={selectedElementType}
            styles={styles}
            onStyleChange={onStyleChange}
          />
        </TabsContent>

        <TabsContent value="chat" className="flex-1 m-0 overflow-hidden">
          <ChatSidebar
            messages={chatMessages}
            onSendMessage={onSendChatMessage}
            isProcessing={isChatProcessing}
            redesignUrl={redesignUrl}
            onOpenBrand={onOpenBrand}
            onTemplateChange={onTemplateChange}
            currentTemplate={currentTemplate}
            onApplyBrandStyles={onApplyBrandStyles}
            hasBrandStyle={hasBrandStyle}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

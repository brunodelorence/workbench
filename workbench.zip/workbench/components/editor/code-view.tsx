"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Copy, Check, FileCode, FolderTree } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

interface CodeViewProps {
  selectedElementId: string | null
}

const codeSnippets: Record<string, { filename: string; code: string }> = {
  "hero-heading": {
    filename: "components/hero.tsx",
    code: `export function Hero() {
  return (
    <section className="flex flex-col items-center justify-center px-8 py-12">
      <h1 className="text-5xl font-medium text-gray-700 text-center leading-tight max-w-lg">
        Save time &
        <br />
        money with
        <br />
        Unimal
      </h1>
      <p className="mt-6 text-gray-500 text-center">
        Savings, visibility, and infrastructure guardrails.
        <br />
        One automated platform.
      </p>
      <button className="mt-8 px-6 py-3 bg-gray-900 text-white text-sm font-medium rounded-lg flex items-center gap-2">
        <span className="text-yellow-400">⟩⟩</span>
        Book a demo
      </button>
    </section>
  )
}`
  },
  "hero-subtitle": {
    filename: "components/hero.tsx",
    code: `<p className="mt-6 text-gray-500 text-center">
  Savings, visibility, and infrastructure guardrails.
  <br />
  One automated platform.
</p>`
  },
  "hero-button": {
    filename: "components/hero.tsx",
    code: `<button className="mt-8 px-6 py-3 bg-gray-900 text-white text-sm font-medium rounded-lg flex items-center gap-2 hover:bg-gray-800 transition-colors">
  <span className="text-yellow-400">⟩⟩</span>
  Book a demo
</button>`
  },
  "dashboard": {
    filename: "components/dashboard-preview.tsx",
    code: `export function DashboardPreview() {
  return (
    <div className="w-full max-w-4xl bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-48 border-r border-gray-100 p-4">
          <div className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 bg-gray-50 rounded">
            <MenuIcon className="w-4 h-4" />
            All Accounts
          </div>
          <nav className="mt-4 space-y-1">
            <NavItem icon={<HomeIcon />} active>Dashboard</NavItem>
            <NavItem icon={<ShieldIcon />}>Guardrails</NavItem>
          </nav>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 p-6">
          <DashboardHeader />
          <StatsGrid />
          <ServiceSpend />
          <SpendChart />
        </div>
        
        {/* Guardrails Sidebar */}
        <GuardrailsPanel alerts={10} />
      </div>
    </div>
  )
}`
  }
}

const fileTree = [
  { name: "app", type: "folder", children: [
    { name: "layout.tsx", type: "file" },
    { name: "page.tsx", type: "file" },
    { name: "globals.css", type: "file" },
  ]},
  { name: "components", type: "folder", children: [
    { name: "hero.tsx", type: "file", active: true },
    { name: "header.tsx", type: "file" },
    { name: "dashboard-preview.tsx", type: "file" },
    { name: "footer.tsx", type: "file" },
  ]},
  { name: "lib", type: "folder", children: [
    { name: "utils.ts", type: "file" },
  ]},
]

export function CodeView({ selectedElementId }: CodeViewProps) {
  const [copied, setCopied] = useState(false)
  const currentCode = selectedElementId ? codeSnippets[selectedElementId] : null

  const handleCopy = () => {
    if (currentCode) {
      navigator.clipboard.writeText(currentCode.code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="flex h-full bg-[#1e1e1e]">
      {/* File Tree */}
      <div className="w-56 border-r border-[#333] bg-[#252526]">
        <div className="p-3 border-b border-[#333] flex items-center gap-2">
          <FolderTree className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-300 font-medium">Explorer</span>
        </div>
        <ScrollArea className="h-[calc(100%-48px)]">
          <div className="p-2">
            {fileTree.map((item, i) => (
              <FileTreeItem key={i} item={item} level={0} />
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Code Editor */}
      <div className="flex-1 flex flex-col">
        {/* Tabs */}
        <div className="h-9 bg-[#252526] border-b border-[#333] flex items-center">
          {currentCode && (
            <div className="flex items-center gap-2 px-4 h-full bg-[#1e1e1e] border-r border-[#333]">
              <FileCode className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-gray-300">{currentCode.filename}</span>
            </div>
          )}
        </div>

        {/* Code Content */}
        <ScrollArea className="flex-1">
          {currentCode ? (
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-4 right-4 text-gray-400 hover:text-white hover:bg-[#333] bg-transparent"
                onClick={handleCopy}
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
              <pre className="p-6 text-sm font-mono leading-relaxed">
                <code className="text-gray-300">
                  {highlightCode(currentCode.code)}
                </code>
              </pre>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <FileCode className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select an element to view its code</p>
              </div>
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  )
}

function FileTreeItem({ item, level }: { item: any; level: number }) {
  const [expanded, setExpanded] = useState(true)
  const isFolder = item.type === "folder"
  
  return (
    <div>
      <div 
        className={cn(
          "flex items-center gap-1.5 py-1 px-2 rounded text-sm cursor-pointer hover:bg-[#333]",
          item.active && "bg-[#37373d]"
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => isFolder && setExpanded(!expanded)}
      >
        {isFolder ? (
          <svg className={cn("w-3 h-3 text-gray-400 transition-transform", expanded && "rotate-90")} fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
          </svg>
        ) : (
          <span className="w-3" />
        )}
        {isFolder ? (
          <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" />
          </svg>
        ) : (
          <FileCode className="w-4 h-4 text-blue-400" />
        )}
        <span className={cn("text-gray-300", item.active && "text-white")}>{item.name}</span>
      </div>
      {isFolder && expanded && item.children && (
        <div>
          {item.children.map((child: any, i: number) => (
            <FileTreeItem key={i} item={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

function highlightCode(code: string) {
  // Simple syntax highlighting
  const lines = code.split('\n')
  return lines.map((line, i) => {
    let highlighted = line
      // Keywords
      .replace(/\b(export|function|return|const|import|from)\b/g, '<span class="text-purple-400">$1</span>')
      // JSX tags
      .replace(/(<\/?)([\w]+)/g, '$1<span class="text-blue-400">$2</span>')
      // Strings
      .replace(/(["'`])(.*?)\1/g, '<span class="text-green-400">$1$2$1</span>')
      // className
      .replace(/className=/g, '<span class="text-yellow-300">className</span>=')
      // Comments
      .replace(/(\/\/.*$)/g, '<span class="text-gray-500">$1</span>')
      .replace(/(\/\*.*\*\/)/g, '<span class="text-gray-500">$1</span>')
      // Curly braces content
      .replace(/(\{[^}]*\})/g, '<span class="text-cyan-300">$1</span>')
    
    return (
      <div key={i} className="flex">
        <span className="w-8 text-right pr-4 text-gray-600 select-none">{i + 1}</span>
        <span dangerouslySetInnerHTML={{ __html: highlighted }} />
      </div>
    )
  })
}

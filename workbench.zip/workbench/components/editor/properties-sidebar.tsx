"use client"

import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Undo2, AlignLeft, AlignCenter, AlignRight, AlignJustify, Italic, Strikethrough, Underline, Underline as Overline, Ban, Lock, Maximize2, MoreHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"

export interface ElementStyles {
  fontFamily: string
  fontWeight: string
  fontSize: string
  lineHeight: string
  letterSpacing: string
  textAlign: string
  textDecoration: string
  color: string
  background: string
  marginX: string
  marginY: string
  paddingX: string
  paddingY: string
  gapX: string
  gapY: string
  borderStyle: string
  borderColor: string
}

interface PropertiesSidebarProps {
  selectedElementId: string | null
  selectedElementType: string
  styles: ElementStyles
  onStyleChange: (styles: Partial<ElementStyles>) => void
}

export function PropertiesSidebar({ selectedElementId, selectedElementType, styles, onStyleChange }: PropertiesSidebarProps) {
  const handleStyleChange = (key: keyof ElementStyles, value: string) => {
    onStyleChange({ [key]: value })
  }
  const elementTag = selectedElementType; // Declare the elementTag variable
  return (
    <div className="w-full bg-background flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-600 rounded border border-blue-200">
            <span className="text-blue-400 mr-1">◇</span>
            {selectedElementType}
          </span>
        </div>
        <Button variant="ghost" size="icon-sm">
          <MoreHorizontal className="size-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-6">
          {/* Typography Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Typography</h3>
            
            {/* Font Family */}
            <Select value={styles.fontFamily} onValueChange={(v) => handleStyleChange("fontFamily", v)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select font" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="inter">Inter</SelectItem>
                <SelectItem value="poppins">Poppins</SelectItem>
                <SelectItem value="roboto">Roboto</SelectItem>
              </SelectContent>
            </Select>

            {/* Font Weight & Size */}
            <div className="grid grid-cols-2 gap-3">
              <Select value={styles.fontWeight} onValueChange={(v) => handleStyleChange("fontWeight", v)}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Light">Light</SelectItem>
                  <SelectItem value="Regular">Regular</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Semibold">Semibold</SelectItem>
                  <SelectItem value="Bold">Bold</SelectItem>
                </SelectContent>
              </Select>
              <Select value={styles.fontSize} onValueChange={(v) => handleStyleChange("fontSize", v)}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="xs">xs</SelectItem>
                  <SelectItem value="sm">sm</SelectItem>
                  <SelectItem value="base">base</SelectItem>
                  <SelectItem value="lg">lg</SelectItem>
                  <SelectItem value="xl">xl</SelectItem>
                  <SelectItem value="2xl">2xl</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Line Height & Letter Spacing */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 min-w-0">
                <label className="text-xs text-muted-foreground">Line Height</label>
                <Input 
                  value={styles.lineHeight}
                  onChange={(e) => handleStyleChange("lineHeight", e.target.value)}
                  className="h-9 w-full"
                />
              </div>
              <div className="space-y-1.5 min-w-0">
                <label className="text-xs text-muted-foreground">Letter Spacing</label>
                <Input 
                  value={styles.letterSpacing}
                  onChange={(e) => handleStyleChange("letterSpacing", e.target.value)}
                  className="h-9 w-full"
                />
              </div>
            </div>

            {/* Alignment & Decoration */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 min-w-0">
                <label className="text-xs text-muted-foreground">Alignment</label>
                <div className="flex items-center gap-0.5 p-1 bg-muted rounded-md overflow-hidden">
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textAlign === "undo" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textAlign", "undo")}
                  >
                    <Undo2 className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textAlign === "left" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textAlign", "left")}
                  >
                    <AlignLeft className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textAlign === "center" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textAlign", "center")}
                  >
                    <AlignCenter className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textAlign === "right" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textAlign", "right")}
                  >
                    <AlignRight className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textAlign === "justify" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textAlign", "justify")}
                  >
                    <AlignJustify className="size-3.5" />
                  </Button>
                </div>
              </div>
              <div className="space-y-1.5 min-w-0">
                <label className="text-xs text-muted-foreground">Decoration</label>
                <div className="flex items-center gap-0.5 p-1 bg-muted rounded-md overflow-hidden">
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textDecoration === "italic" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textDecoration", "italic")}
                  >
                    <Italic className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textDecoration === "line-through" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textDecoration", "line-through")}
                  >
                    <Strikethrough className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textDecoration === "underline" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textDecoration", "underline")}
                  >
                    <Underline className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textDecoration === "overline" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textDecoration", "overline")}
                  >
                    <Overline className="size-3.5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon-sm"
                    className={cn("h-7 w-7", styles.textDecoration === "none" && "bg-background shadow-sm")}
                    onClick={() => onStyleChange("textDecoration", "none")}
                  >
                    <Ban className="size-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Color Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Color</h3>
            <Select value={styles.color} onValueChange={(v) => handleStyleChange("color", v)}>
              <SelectTrigger className="w-full">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-gray-700" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text-gray-700">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gray-700" />
                    text-gray-700
                  </div>
                </SelectItem>
                <SelectItem value="text-gray-900">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gray-900" />
                    text-gray-900
                  </div>
                </SelectItem>
                <SelectItem value="text-gray-500">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gray-500" />
                    text-gray-500
                  </div>
                </SelectItem>
                <SelectItem value="text-blue-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-blue-600" />
                    text-blue-600
                  </div>
                </SelectItem>
                <SelectItem value="text-blue-500">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-blue-500" />
                    text-blue-500
                  </div>
                </SelectItem>
                <SelectItem value="text-green-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-green-600" />
                    text-green-600
                  </div>
                </SelectItem>
                <SelectItem value="text-red-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-red-600" />
                    text-red-600
                  </div>
                </SelectItem>
                <SelectItem value="text-white">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-white border" />
                    text-white
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Background Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Background</h3>
            <Select value={styles.background} onValueChange={(v) => handleStyleChange("background", v)}>
              <SelectTrigger className="w-full">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded border border-dashed border-gray-300" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Default">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded border border-dashed border-gray-300" />
                    Default
                  </div>
                </SelectItem>
                <SelectItem value="bg-white">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-white border border-gray-200" />
                    bg-white
                  </div>
                </SelectItem>
                <SelectItem value="bg-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gray-100" />
                    bg-gray-100
                  </div>
                </SelectItem>
                <SelectItem value="bg-gray-900">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gray-900" />
                    bg-gray-900
                  </div>
                </SelectItem>
                <SelectItem value="bg-blue-50">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-blue-50" />
                    bg-blue-50
                  </div>
                </SelectItem>
                <SelectItem value="bg-blue-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-blue-600" />
                    bg-blue-600
                  </div>
                </SelectItem>
                <SelectItem value="bg-green-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-green-600" />
                    bg-green-600
                  </div>
                </SelectItem>
                <SelectItem value="bg-red-600">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-red-600" />
                    bg-red-600
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Margin Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Margin</h3>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="1" y="4" width="12" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.marginY}
                  onChange={(e) => onStyleChange("marginY", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="4" y="1" width="6" height="12" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.marginX}
                  onChange={(e) => onStyleChange("marginX", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <Button variant="ghost" size="icon-sm" className="shrink-0">
                <Maximize2 className="size-4" />
              </Button>
              <Button variant="ghost" size="icon-sm" className="shrink-0">
                <Lock className="size-4" />
              </Button>
            </div>
          </div>

          {/* Padding Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Padding</h3>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="1" y="4" width="12" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.paddingY}
                  onChange={(e) => handleStyleChange("paddingY", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="4" y="1" width="6" height="12" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.paddingX}
                  onChange={(e) => handleStyleChange("paddingX", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <Button variant="ghost" size="icon-sm" className="shrink-0">
                <Maximize2 className="size-4" />
              </Button>
              <Button variant="ghost" size="icon-sm" className="shrink-0">
                <Lock className="size-4" />
              </Button>
            </div>
          </div>

          {/* Gap Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Gap</h3>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="1" y="4" width="12" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.gapY}
                  onChange={(e) => handleStyleChange("gapY", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="4" y="1" width="6" height="12" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </span>
                <Input 
                  value={styles.gapX}
                  onChange={(e) => handleStyleChange("gapX", e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <Button variant="ghost" size="icon-sm" className="shrink-0 invisible">
                <Maximize2 className="size-4" />
              </Button>
              <Button variant="ghost" size="icon-sm" className="shrink-0">
                <Lock className="size-4" />
              </Button>
            </div>
          </div>

          {/* Border Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Border</h3>
            <div className="grid grid-cols-2 gap-3">
              <Select value={styles.borderStyle} onValueChange={(v) => handleStyleChange("borderStyle", v)}>
                <SelectTrigger className="w-full">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded border border-dashed border-gray-300" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Default">Default</SelectItem>
                  <SelectItem value="solid">Solid</SelectItem>
                  <SelectItem value="dashed">Dashed</SelectItem>
                  <SelectItem value="dotted">Dotted</SelectItem>
                </SelectContent>
              </Select>
              <Select value={styles.borderColor} onValueChange={(v) => handleStyleChange("borderColor", v)}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Default">Default</SelectItem>
                  <SelectItem value="border-gray-200">border-gray-200</SelectItem>
                  <SelectItem value="border-gray-300">border-gray-300</SelectItem>
                  <SelectItem value="border-blue-500">border-blue-500</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

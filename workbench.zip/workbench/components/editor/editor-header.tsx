"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ChevronLeft, ChevronRight, Globe, Lock, Share2, ExternalLink, Sparkles, ChevronDown, Home } from "lucide-react"
import { cn } from "@/lib/utils"

interface EditorHeaderProps {
  currentVersion: number
  totalVersions: number
  onVersionChange: (version: number) => void
  activeTab: string
  onTabChange: (tab: string) => void
  onOpenRecommendations?: () => void
  onOpenBrand?: () => void
  onGoHome?: () => void
  redesignUrl?: string
}

const deploymentLogs = [
  { time: "17:13:44", message: "Initializing list of deployment files..." },
  { time: "17:13:44", message: "Previous build caches not available" },
  { time: "17:13:45", message: "Downloading 90 deployment files..." },
  { time: "17:13:45", message: 'Running "build"' },
  { time: "17:13:46", message: "Build System 42.2.0" },
  { time: "17:13:46", message: "Running \"install\" command: `bun install\n`..." },
  { time: "17:13:46", message: "bun install v1.2.13 (64ed68c9)" },
  { time: "17:13:46", message: "Resolving dependencies" },
  { time: "17:13:47", message: "Installing packages..." },
  { time: "17:13:48", message: "Building application..." },
  { time: "17:13:49", message: "Optimizing assets..." },
  { time: "17:13:50", message: "Deployment complete!" },
]

export function EditorHeader({ 
  currentVersion, 
  totalVersions, 
  onVersionChange, 
  activeTab, 
  onTabChange,
  onOpenRecommendations,
  onOpenBrand,
  onGoHome,
  redesignUrl = "https://unimal.jp/"
}: EditorHeaderProps) {
  const versions = Array.from({ length: totalVersions }, (_, i) => i + 1)
  const [isDeploying, setIsDeploying] = useState(false)
  const [deployOpen, setDeployOpen] = useState(false)
  const [visibleLogs, setVisibleLogs] = useState<typeof deploymentLogs>([])
  const [deployStatus, setDeployStatus] = useState<"idle" | "deploying" | "complete">("idle")

  const startDeployment = useCallback(() => {
    if (deployStatus === "complete") {
      // Already deployed, just open the popover
      setDeployOpen(true)
      return
    }
    setIsDeploying(true)
    setDeployOpen(true)
    setVisibleLogs([])
    setDeployStatus("deploying")
  }, [deployStatus])

  useEffect(() => {
    if (!isDeploying) return

    let currentIndex = 0
    const interval = setInterval(() => {
      if (currentIndex < deploymentLogs.length) {
        setVisibleLogs(prev => [...prev, deploymentLogs[currentIndex]])
        currentIndex++
      } else {
        clearInterval(interval)
        setDeployStatus("complete")
        setIsDeploying(false)
      }
    }, 400)

    return () => clearInterval(interval)
  }, [isDeploying])

  const handleOpenChange = (open: boolean) => {
    setDeployOpen(open)
    if (!open && deployStatus === "idle") {
      setVisibleLogs([])
    }
  }

  const getButtonContent = () => {
    if (deployStatus === "deploying") {
      return (
        <>
          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          Updating your website
        </>
      )
    }
    return (
      <>
        <Globe className="w-4 h-4" />
        Publish
      </>
    )
  }

  const getButtonClass = () => {
    if (deployStatus === "deploying") {
      return "gap-2 bg-orange-500 hover:bg-orange-600 text-white"
    }
    return "gap-2 bg-blue-600 hover:bg-blue-700 text-white"
  }

  return (
    <div className="h-14 border-b border-border bg-background flex items-center justify-between px-4">
      {/* Left Section - Project Info */}
      <div className="flex items-center gap-3">
        <Button 
          variant="ghost" 
          size="icon-sm" 
          className="h-8 w-8"
          onClick={onGoHome}
          title="Back to Home"
        >
          <Home className="w-4 h-4" />
        </Button>
        <div className="h-6 w-px bg-gray-200" />
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center">
            <span className="text-white text-xs font-bold">P</span>
          </div>
          <span className="text-sm font-medium">Personal</span>
          <span className="px-1.5 py-0.5 text-[10px] font-medium bg-gray-100 text-gray-600 rounded">Free</span>
        </div>
        <span className="text-gray-300">/</span>
        <span className="text-sm text-gray-600">Redesign {redesignUrl}</span>
        <div className="flex items-center gap-1 text-xs text-gray-500">
          <Lock className="w-3 h-3" />
          Private
        </div>
      </div>

      {/* Center Section - Tabs */}
      <Tabs value={activeTab} onValueChange={onTabChange} className="absolute left-1/2 -translate-x-1/2">
        <TabsList className="bg-transparent border-none h-auto p-0 gap-0">
          <TabsTrigger 
            value="preview" 
            className={cn(
              "rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-gray-900 data-[state=active]:bg-transparent data-[state=active]:shadow-none",
              "text-sm font-medium"
            )}
          >
            Preview
          </TabsTrigger>
          <TabsTrigger 
            value="code" 
            className={cn(
              "rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-gray-900 data-[state=active]:bg-transparent data-[state=active]:shadow-none",
              "text-sm font-medium"
            )}
          >
            Code
          </TabsTrigger>
          <TabsTrigger 
            value="compare" 
            className={cn(
              "rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-gray-900 data-[state=active]:bg-transparent data-[state=active]:shadow-none",
              "text-sm font-medium"
            )}
          >
            Compare
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Right Section - Versions & Actions */}
      <div className="flex items-center gap-3">
        {/* Version Navigation */}
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon-sm" 
            className="h-7 w-7"
            onClick={() => onVersionChange(Math.max(1, currentVersion - 1))}
            disabled={currentVersion === 1}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <div className="flex items-center gap-0.5">
            {versions.map((v) => (
              <button
                key={v}
                onClick={() => onVersionChange(v)}
                className={cn(
                  "w-7 h-7 rounded text-xs font-medium transition-colors",
                  currentVersion === v 
                    ? "bg-gray-900 text-white" 
                    : "text-gray-600 hover:bg-gray-100"
                )}
              >
                V{v}
              </button>
            ))}
          </div>

          <Button 
            variant="ghost" 
            size="icon-sm" 
            className="h-7 w-7"
            onClick={() => onVersionChange(Math.min(totalVersions, currentVersion + 1))}
            disabled={currentVersion === totalVersions}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Action Buttons */}
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2 bg-gradient-to-r from-violet-500/10 to-purple-500/10 border-violet-200 hover:border-violet-300 hover:bg-gradient-to-r hover:from-violet-500/20 hover:to-purple-500/20 text-violet-700"
          onClick={onOpenRecommendations}
        >
          <Sparkles className="w-4 h-4" />
          AI Insights
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2 bg-transparent"
          onClick={onOpenBrand}
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <path d="M21 15l-5-5L5 21" />
          </svg>
          Brand
        </Button>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          <Share2 className="w-4 h-4" />
          Share
        </Button>
        
        <Popover open={deployOpen} onOpenChange={handleOpenChange}>
          <PopoverTrigger asChild>
            <Button 
              size="sm" 
              className={getButtonClass()}
              onClick={startDeployment}
              disabled={deployStatus === "deploying"}
            >
              {getButtonContent()}
            </Button>
          </PopoverTrigger>
          <PopoverContent 
            align="end" 
            className="w-[420px] p-0 overflow-hidden"
            sideOffset={8}
          >
            {deployStatus === "complete" ? (
              // Success State - Site Preview
              <div className="overflow-hidden">
                {/* Site Preview Image */}
                <div className="relative bg-gray-600 aspect-video flex items-center justify-center">
                  {/* Simulated site preview with overlay */}
                  <div className="absolute inset-0 bg-gray-700/90 flex flex-col items-center justify-center text-white">
                    <h2 className="text-2xl font-semibold text-center leading-tight px-8">
                      Save time &<br />money with
                    </h2>
                    <p className="text-xs text-gray-400 mt-4 text-center px-8">
                      Savings, visibility, and infrastructure guardrails.<br />
                      One automated platform.
                    </p>
                    <div className="mt-4 flex items-center gap-2">
                      <div className="w-6 h-6 bg-green-400 rounded flex items-center justify-center">
                        <ChevronRight className="w-4 h-4 text-gray-900" />
                      </div>
                      <span className="text-xs bg-gray-800 px-3 py-1.5 rounded text-white">Book a demo</span>
                    </div>
                  </div>
                  
                  {/* Visit Site Button Overlay */}
                  <a 
                    href="https://unimal.preview.app" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <div className="bg-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 hover:bg-gray-50 transition-colors">
                      <span className="text-sm font-medium text-gray-900">Visit Site</span>
                      <ExternalLink className="w-4 h-4 text-gray-600" />
                    </div>
                  </a>
                </div>

                {/* Footer Section */}
                <div className="bg-white p-4 space-y-4">
                  {/* URL and User Info */}
                  <div className="flex items-center justify-between">
                    <a 
                      href="https://unimal.preview.app" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-sm font-medium text-gray-900 hover:underline"
                    >
                      unimal.preview.app
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Last updated 14m ago</span>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-green-500" />
                      <span>brunodelorence-8291</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="outline" 
                      className="flex-1 bg-transparent"
                    >
                      Add domain
                    </Button>
                    <Button 
                      className="flex-1 gap-2 bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Deploy v.04
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              // Deploying State - Logs
              <>
                <div className="bg-gray-50 p-4 max-h-[240px] overflow-y-auto font-mono text-xs">
                  {visibleLogs && visibleLogs.length > 0 && visibleLogs.map((log, index) => (
                    log && (
                      <div 
                        key={index} 
                        className="text-gray-600 leading-relaxed animate-in fade-in slide-in-from-bottom-1 duration-200"
                        style={{ animationDelay: `${index * 50}ms` }}
                      >
                        <span className="text-gray-400">{log.time}</span>{" "}
                        <span className="whitespace-pre-wrap">{log.message}</span>
                      </div>
                    )
                  ))}
                  {visibleLogs.length === 0 && (
                    <div className="text-gray-400">Initializing deployment...</div>
                  )}
                </div>

                {/* Footer Section */}
                <div className="border-t border-gray-200 bg-white p-4 space-y-3">
                  {/* URL and User Info */}
                  <div className="flex items-center justify-between">
                    <a 
                      href="https://unimal.preview.app" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-sm font-medium text-gray-900 hover:underline"
                    >
                      unimal.preview.app
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Last updated 14m ago</span>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-green-500" />
                      <span>brunodelorence-8291</span>
                    </div>
                  </div>

                  {/* Deploy Status Button */}
                  <Button 
                    variant="outline" 
                    className="w-full gap-2 bg-transparent"
                    disabled
                  >
                    <Sparkles className="w-4 h-4 animate-pulse" />
                    Deploying
                  </Button>
                </div>
              </>
            )}
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}

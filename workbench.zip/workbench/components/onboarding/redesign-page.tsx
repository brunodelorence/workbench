"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { 
  Clock, 
  LayoutGrid, 
  Users, 
  ChevronDown, 
  Sparkles, 
  Paperclip, 
  ArrowUp,
  ExternalLink,
  MessageSquarePlus
} from "lucide-react"

interface RedesignPageProps {
  onStartRedesign: (url: string, prompt: string) => void
}

const recentUrls = [
  "https://unimal.jp/",
  "https://www.yahoo.co.jp",
  "https://www.google.co.jp/",
  "https://www.goo.ne.jp/",
  "https://www.livedoor.com/",
]

const templates = [
  {
    id: 1,
    category: "Design",
    categoryColor: "text-blue-600",
    title: "UX review presentations",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&h=400&fit=crop",
    subtitle: "Comprehensive Pest Control Services"
  },
  {
    id: 2,
    category: "Product",
    categoryColor: "text-green-600",
    title: "Marketing Agency Homepage",
    image: "https://images.unsplash.com/photo-1586880244406-556ebe35f282?w=600&h=400&fit=crop",
    subtitle: "Making Your Move Quick & Easy"
  },
  {
    id: 3,
    category: "Software Engineering",
    categoryColor: "text-purple-600",
    title: "Digital Consulting Homepage",
    image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600&h=400&fit=crop",
    subtitle: "Love, Care, And Everything Pets Need"
  },
  {
    id: 4,
    category: "Business",
    categoryColor: "text-teal-600",
    title: "Corporate Landing Page",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop",
    subtitle: "Transforming businesses to compete for tomorrow"
  },
  {
    id: 5,
    category: "Marketing",
    categoryColor: "text-orange-600",
    title: "Modern Marketing Site",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    subtitle: "Modern Marketers Deserve Better"
  },
  {
    id: 6,
    category: "Consulting",
    categoryColor: "text-indigo-600",
    title: "Coaching Platform",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    subtitle: "Monthly Coaching & Consulting Agency"
  },
]

export function RedesignPage({ onStartRedesign }: RedesignPageProps) {
  const [url, setUrl] = useState("")
  const [prompt, setPrompt] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState("none")
  const [selectedModel, setSelectedModel] = useState("ai-medium")
  const [sidebarSection, setSidebarSection] = useState("recents")

  const handleSubmit = () => {
    if (url.trim()) {
      onStartRedesign(url, prompt)
    }
  }

  const handleTemplateClick = (template: typeof templates[0]) => {
    setPrompt(`Create a ${template.title.toLowerCase()} style website`)
    onStartRedesign("https://example.com", `Create a ${template.title.toLowerCase()} style website based on the ${template.category} template`)
  }

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div className="w-[220px] border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-3 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <img 
              src="/images/logo.png" 
              alt="Logo" 
              className="w-6 h-6"
            />
            <span className="font-medium text-sm">Personal</span>
            <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-600">Free</span>
            <ChevronDown className="w-3 h-3 text-gray-400 ml-auto" />
          </div>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <Button variant="outline" className="w-full justify-center gap-2 h-9 text-sm bg-transparent">
            <MessageSquarePlus className="w-4 h-4" />
            New Chat
          </Button>
        </div>

        {/* Navigation */}
        <nav className="px-2">
          <button
            type="button"
            onClick={() => setSidebarSection("recents")}
            className={cn(
              "w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors",
              sidebarSection === "recents" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <Clock className="w-4 h-4" />
            Recents
          </button>
          <button
            type="button"
            onClick={() => setSidebarSection("projects")}
            className={cn(
              "w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors",
              sidebarSection === "projects" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <LayoutGrid className="w-4 h-4" />
            Projects
          </button>
          <button
            type="button"
            onClick={() => setSidebarSection("community")}
            className={cn(
              "w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors",
              sidebarSection === "community" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <Users className="w-4 h-4" />
            Community
          </button>
        </nav>

        {/* Recents Redesign */}
        <div className="mt-4 px-2">
          <button
            type="button"
            className="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-500"
          >
            <span>Recents Redesign</span>
            <ChevronDown className="w-3 h-3" />
          </button>
          <div className="mt-1 space-y-0.5">
            {recentUrls.map((recentUrl) => (
              <button
                key={recentUrl}
                type="button"
                onClick={() => setUrl(recentUrl)}
                className="w-full text-left px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-50 rounded truncate"
              >
                {recentUrl}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="h-12 border-b border-gray-200 flex items-center justify-between px-4">
          <button type="button" className="p-2 hover:bg-gray-100 rounded">
            <svg className="w-5 h-5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="M9 3v18" />
            </svg>
          </button>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="bg-transparent">
              Feedback
            </Button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-pink-500" />
          </div>
        </div>

        {/* Content Area */}
        <ScrollArea className="flex-1">
          <div className="max-w-3xl mx-auto px-6 py-12">
            {/* Gradient Orb */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-400 via-pink-500 to-purple-600 shadow-lg shadow-purple-200" />
            </div>

            {/* AI Badge */}
            <div className="flex justify-center mb-8">
              <div className="inline-flex items-center gap-2 px-1 py-1 bg-blue-50 rounded-full">
                <span className="px-2 py-0.5 bg-white rounded-full text-xs font-medium text-blue-600 shadow-sm">A.I</span>
                <span className="text-sm text-blue-600 pr-3">AI will create a cool website for you</span>
              </div>
            </div>

            {/* Title */}
            <h1 className="text-4xl font-semibold text-center text-gray-900 mb-8">
              What do you want to redesign?
            </h1>

            {/* URL Input */}
            <div className="mb-4">
              <Input
                placeholder="Ex: https://unimal.jp/"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="h-12 text-base border-gray-200 focus-visible:ring-blue-500"
              />
            </div>

            {/* Prompt Area */}
            <div className="border border-gray-200 rounded-xl p-4 mb-8">
              <textarea
                placeholder="Ask AI to redesign your website..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full resize-none border-0 focus:outline-none text-base text-gray-700 placeholder:text-gray-400 min-h-[60px]"
              />
              
              {/* Controls */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-100 mt-2">
                <div className="flex items-center gap-2">
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger className="h-8 w-auto border-gray-200 text-sm bg-gray-50">
                      <SelectValue placeholder="No template selected" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No template selected</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                      <SelectItem value="modern">Modern</SelectItem>
                      <SelectItem value="classic">Classic</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={selectedModel} onValueChange={setSelectedModel}>
                    <SelectTrigger className="h-8 w-auto border-gray-200 text-sm bg-gray-50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ai-fast">ai-fast</SelectItem>
                      <SelectItem value="ai-medium">ai-medium</SelectItem>
                      <SelectItem value="ai-quality">ai-quality</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-gray-600">
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M5 3l14 9-14 9V3z" />
                    </svg>
                    Import from Figma
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Sparkles className="w-4 h-4 text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Paperclip className="w-4 h-4 text-gray-500" />
                  </Button>
                  <Button 
                    size="icon" 
                    className="h-8 w-8 rounded-full bg-gray-900 hover:bg-gray-800"
                    onClick={handleSubmit}
                    disabled={!url.trim()}
                  >
                    <ArrowUp className="w-4 h-4 text-white" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Templates Section */}
            <div className="mt-12">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg font-semibold text-gray-900">From the Templates Community</h2>
                <button type="button" className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1">
                  Browse All
                  <ChevronDown className="w-4 h-4 -rotate-90" />
                </button>
              </div>
              <p className="text-sm text-gray-500 mb-6">Explore what the template is building for you</p>

              {/* Template Grid */}
              <div className="grid grid-cols-3 gap-6">
                {templates.map((template) => (
                  <div key={template.id} className="group">
                    {/* Preview Image */}
                    <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-gray-100 mb-3">
                      <img
                        src={template.image || "/placeholder.svg"}
                        alt={template.title}
                        className="w-full h-full object-cover"
                      />
                      {/* Overlay content simulation */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3">
                        <p className="text-white text-xs font-medium">{template.subtitle}</p>
                      </div>
                    </div>

                    {/* Template Info */}
                    <div className="mb-2">
                      <span className={cn("text-xs font-medium", template.categoryColor)}>
                        {template.category}
                      </span>
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-gray-900">{template.title}</h3>
                        <ExternalLink className="w-4 h-4 text-gray-400" />
                      </div>
                    </div>

                    {/* Use Template Button */}
                    <Button
                      variant="outline"
                      className="w-full bg-transparent hover:bg-gray-50"
                      onClick={() => handleTemplateClick(template)}
                    >
                      Use this template
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}

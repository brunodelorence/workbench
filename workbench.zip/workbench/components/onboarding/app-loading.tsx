"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Paperclip, Smile, ChevronDown, ExternalLink } from "lucide-react"

interface AppLoadingProps {
  onComplete: () => void
  url: string
  prompt: string
}

interface ThinkingStep {
  type: "bullet" | "paragraph" | "question"
  content: string
}

export function AppLoading({ onComplete, url, prompt }: AppLoadingProps) {
  const [visibleSteps, setVisibleSteps] = useState<number>(0)
  const [isStopped, setIsStopped] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  const thinkingSteps: ThinkingStep[] = [
    { type: "bullet", content: `Analyze the website structure at ${url}` },
    { type: "bullet", content: "Identify key design elements and components" },
    { type: "paragraph", content: `Since this is a redesign request for "${prompt}", I should understand the current site structure and identify areas for improvement:` },
    { type: "question", content: "What is the main purpose of the website?" },
    { type: "question", content: "What are the key conversion elements?" },
    { type: "question", content: "How can I improve the visual hierarchy?" },
    { type: "bullet", content: "Extracting color palette and typography" },
    { type: "bullet", content: "Generating improved layout suggestions" },
    { type: "paragraph", content: "Based on the analysis, I'll create a modern, clean redesign that maintains the brand identity while improving user experience and visual appeal." },
    { type: "bullet", content: "Building the new design components" },
    { type: "bullet", content: "Applying responsive layout patterns" },
  ]

  const actionSuggestions = [
    { label: "Selector Design area", icon: true },
    { label: "Add form validation", hasArrow: true },
    { label: "Add server validation", hasArrow: true },
    { label: "Add design interaction", hasArrow: true },
  ]

  useEffect(() => {
    if (isStopped) return

    const interval = setInterval(() => {
      setVisibleSteps(prev => {
        if (prev >= thinkingSteps.length) {
          clearInterval(interval)
          setIsComplete(true)
          setTimeout(() => {
            if (!isStopped) {
              onComplete()
            }
          }, 1500)
          return prev
        }
        return prev + 1
      })
    }, 800)

    return () => clearInterval(interval)
  }, [isStopped, thinkingSteps.length, onComplete])

  const handleStop = () => {
    setIsStopped(true)
  }

  const handleContinue = () => {
    setIsStopped(false)
    if (isComplete) {
      onComplete()
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Main Content */}
      <div className="flex-1 max-w-3xl mx-auto w-full px-6 py-8">
        {/* User Message */}
        <div className="flex justify-end mb-8">
          <div className="flex items-start gap-3">
            <div className="bg-gray-100 rounded-2xl px-4 py-3 max-w-md">
              <p className="text-gray-900">{prompt || "Redesign this website"}</p>
              {url && (
                <a 
                  href={url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-blue-600 hover:underline flex items-center gap-1 mt-1"
                >
                  {url}
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex-shrink-0" />
          </div>
        </div>

        {/* AI Thinking */}
        <div className="flex gap-3">
          {/* Orb Icon */}
          <div className="w-8 h-8 flex-shrink-0">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
              <svg className="w-4 h-4 text-gray-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 6v6l4 2" />
              </svg>
            </div>
          </div>

          {/* Thinking Content */}
          <div className="flex-1 space-y-4">
            <p className="text-gray-900 font-medium">
              AI is <span className="text-gray-500">thinking...</span>
            </p>

            {/* Thinking Steps */}
            <div className="space-y-3">
              {thinkingSteps.map((step, index) => {
                const isVisible = index < visibleSteps
                const isCurrent = index === visibleSteps - 1 && !isComplete
                const isFuture = index >= visibleSteps

                if (step.type === "bullet") {
                  return (
                    <div 
                      key={index}
                      className={`flex items-start gap-2 transition-all duration-300 ${
                        isVisible 
                          ? "opacity-100 translate-y-0" 
                          : "opacity-0 translate-y-2"
                      } ${isFuture ? "hidden" : ""}`}
                    >
                      <span className={`mt-2 w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                        isCurrent ? "bg-gray-400 animate-pulse" : "bg-gray-800"
                      }`} />
                      <span className={`${isCurrent ? "text-gray-500" : "text-gray-800"}`}>
                        {step.content}
                      </span>
                    </div>
                  )
                }

                if (step.type === "paragraph") {
                  return (
                    <p 
                      key={index}
                      className={`text-gray-700 transition-all duration-300 ${
                        isVisible 
                          ? "opacity-100 translate-y-0" 
                          : "opacity-0 translate-y-2"
                      } ${isFuture ? "hidden" : ""}`}
                    >
                      {step.content}
                    </p>
                  )
                }

                if (step.type === "question") {
                  return (
                    <div 
                      key={index}
                      className={`flex items-start gap-2 transition-all duration-300 ${
                        isVisible 
                          ? "opacity-100 translate-y-0" 
                          : "opacity-0 translate-y-2"
                      } ${isFuture ? "hidden" : ""}`}
                    >
                      <span className={`mt-2 w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                        isCurrent ? "bg-gray-300" : "bg-gray-400"
                      }`} />
                      <span className={`${isCurrent ? "text-gray-400" : "text-gray-500"}`}>
                        {step.content}
                      </span>
                    </div>
                  )
                }

                return null
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="border-t border-gray-100 bg-white">
        <div className="max-w-3xl mx-auto w-full px-6 py-4 space-y-4">
          {/* Action Suggestions */}
          <div className="space-y-2">
            <span className="text-xs text-gray-500 uppercase tracking-wide">Action Suggestions</span>
            <div className="flex flex-wrap gap-2">
              {actionSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  {suggestion.icon && (
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" />
                      <path d="M3 9h18" />
                      <path d="M9 21V9" />
                    </svg>
                  )}
                  {suggestion.label}
                  {suggestion.hasArrow && (
                    <ExternalLink className="w-3 h-3" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="relative">
            <div className="border border-gray-200 rounded-xl bg-white">
              <div className="flex items-center justify-between px-4 py-3">
                <input
                  type="text"
                  placeholder="Ask me anything..."
                  className="flex-1 bg-transparent outline-none text-gray-900 placeholder:text-gray-400"
                  disabled={!isStopped}
                />
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded flex items-center gap-1">
                    <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M12 6v6l4 2" />
                    </svg>
                    No brand style
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between px-4 py-2 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <button className="p-1 text-gray-400 hover:text-gray-600">
                    <Paperclip className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-gray-400 hover:text-gray-600">
                    <Smile className="w-4 h-4" />
                  </button>
                </div>
                {!isStopped ? (
                  <button
                    onClick={handleStop}
                    className="text-red-500 hover:text-red-600 text-sm font-medium"
                  >
                    Stop
                  </button>
                ) : (
                  <Button 
                    size="sm" 
                    onClick={handleContinue}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isComplete ? "Continue to Editor" : "Resume"}
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Template Selector */}
          <div className="flex items-center justify-between">
            <button className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900">
              Marketing Agency template
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          {/* Disclaimer */}
          <p className="text-center text-xs text-gray-400">
            AI may make mistakes. Please use with discretion.
          </p>
        </div>
      </div>
    </div>
  )
}
